import { useCallback, useEffect, useState } from 'react';
import { ClientPortal, type PortalTab } from './components/ClientPortal';
import { HomeShowcase } from './components/HomeShowcase';
import { Navbar, type ActiveWorkspace } from './components/Navbar';
import { OwnerDashboard, type DashboardSection } from './components/OwnerDashboard';
import type { AppStatePayload } from './types/domain';

export default function App() {
  const [state, setState] = useState<AppStatePayload | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const [activeWorkspace, setActiveWorkspace] = useState<ActiveWorkspace>('home');
  const [portalTab, setPortalTab] = useState<PortalTab>('farm');
  const [dashboardSection, setDashboardSection] = useState<DashboardSection>('overview');

  const fetchState = useCallback(async () => {
    try {
      const res = await fetch('/api/state');
      if (!res.ok) {
        throw new Error(`HTTP ${res.status}`);
      }
      const data = (await res.json()) as AppStatePayload;
      setState(data);
      setError(null);
    } catch {
      setError('Unable to load Papio Opulentus operational data.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchState();
  }, [fetchState]);

  const handleNavigateWorkspace = (workspace: ActiveWorkspace, sectionOrTab?: string) => {
    setActiveWorkspace(workspace);
    if (workspace === 'portal') {
      if (
        sectionOrTab === 'farm' ||
        sectionOrTab === 'ehailing' ||
        sectionOrTab === 'microlending' ||
        sectionOrTab === 'requests'
      ) {
        setPortalTab(sectionOrTab);
      }
      window.scrollTo({ top: 0, behavior: 'smooth' });
      return;
    }

    if (workspace === 'dashboard') {
      if (
        sectionOrTab === 'overview' ||
        sectionOrTab === 'farm' ||
        sectionOrTab === 'ehailing' ||
        sectionOrTab === 'microlending' ||
        sectionOrTab === 'verification'
      ) {
        setDashboardSection(sectionOrTab);
      }
      window.scrollTo({ top: 0, behavior: 'smooth' });
      return;
    }

    if (workspace === 'home' && sectionOrTab) {
      setTimeout(() => {
        const el = document.getElementById(sectionOrTab);
        if (el) {
          el.scrollIntoView({ behavior: 'smooth' });
        } else {
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }
      }, 40);
    }
  };

  return (
    <div className="min-h-screen bg-[#FAFAF9] text-stone-900">
      <Navbar
        activeWorkspace={activeWorkspace}
        onNavigateWorkspace={handleNavigateWorkspace}
      />

      {loading && (
        <main className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-16">
          <div className="space-y-6 animate-pulse">
            <div className="h-10 w-80 bg-stone-200 rounded-lg" />
            <div className="h-72 w-full bg-stone-200 rounded-xl" />
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="h-44 bg-stone-200 rounded-xl" />
              <div className="h-44 bg-stone-200 rounded-xl" />
              <div className="h-44 bg-stone-200 rounded-xl" />
            </div>
          </div>
        </main>
      )}

      {!loading && error && (
        <main className="mx-auto max-w-2xl px-4 py-16 text-center">
          <div className="bg-white border border-red-200 rounded-xl p-8">
            <h1 className="font-display text-xl font-bold text-stone-900">
              Connection Unavailable
            </h1>
            <p className="mt-2 text-sm text-stone-600">{error}</p>
            <button
              type="button"
              onClick={fetchState}
              className="mt-5 px-5 py-2.5 bg-stone-900 text-white text-sm font-semibold rounded-lg hover:bg-[#14532D] cursor-pointer"
            >
              Retry Connection
            </button>
          </div>
        </main>
      )}

      {!loading && !error && state && (
        <>
          {activeWorkspace === 'home' && (
            <HomeShowcase
              state={state}
              onNavigateWorkspace={handleNavigateWorkspace}
            />
          )}
          {activeWorkspace === 'portal' && (
            <ClientPortal
              state={state}
              activeTab={portalTab}
              onChangeTab={setPortalTab}
              onRefreshState={fetchState}
            />
          )}
          {activeWorkspace === 'dashboard' && (
            <OwnerDashboard
              state={state}
              activeSection={dashboardSection}
              onChangeSection={setDashboardSection}
              onRefreshState={fetchState}
              onSwitchToPortal={() => handleNavigateWorkspace('portal', 'farm')}
            />
          )}
        </>
      )}
    </div>
  );
}
