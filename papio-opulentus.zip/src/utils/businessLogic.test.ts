import test from 'node:test';
import assert from 'node:assert/strict';
import {
  buildAssetLinksPayload,
  calculateFarmOrderTotal,
  calculateMicroloan,
  calculateRideFare,
  formatZar,
  isValidAndroidPackageName,
  isValidSha256Fingerprint,
  isValidVerificationHtmlFilename,
} from './businessLogic';

test('calculateMicroloan computes principal, interest, initiation fee, and affordability', () => {
  const loan = calculateMicroloan(5000, 6, 3.5, 12000);
  // Initiation fee: 165 + (4000 * 0.05) = 365
  assert.equal(loan.initiationFeeZar, 365);
  // Total interest: 5000 * 0.035 * 6 = 1050
  assert.equal(loan.totalInterestZar, 1050);
  // Total repayable: 5000 + 1050 + 365 = 6415
  assert.equal(loan.totalRepayableZar, 6415);
  assert.equal(loan.monthlyInstallmentZar, 1069.17);
  assert.equal(loan.recommendedEligible, true);
});

test('calculateMicroloan flags unaffordable debt-to-income ratio', () => {
  const loan = calculateMicroloan(15000, 3, 4.0, 4000);
  assert.equal(loan.recommendedEligible, false);
  assert.ok(loan.debtToIncomePct > 40);
});

test('calculateRideFare scales accurately across vehicle classes', () => {
  const sedan = calculateRideFare(24, 'Standard Sedan');
  const suv = calculateRideFare(24, 'Executive SUV');
  const cargo = calculateRideFare(24, 'Farm Cargo Utility');

  assert.equal(sedan.estimatedFareZar, 311);
  assert.equal(suv.estimatedFareZar, 449);
  assert.ok(cargo.estimatedFareZar > suv.estimatedFareZar);
  assert.ok(sedan.estimatedMinutes >= 6);
});

test('calculateFarmOrderTotal waives delivery in Moruleng Village and over threshold', () => {
  const local = calculateFarmOrderTotal(
    [{ itemId: '1', itemName: 'White Maize 50kg', quantity: 2, unitPriceZar: 420 }],
    'Moruleng Village'
  );
  assert.equal(local.subtotalZar, 840);
  assert.equal(local.deliveryFeeZar, 0);
  assert.equal(local.totalZar, 840);

  const regional = calculateFarmOrderTotal(
    [{ itemId: '1', itemName: 'White Maize 50kg', quantity: 2, unitPriceZar: 420 }],
    'Rustenburg CBD'
  );
  assert.equal(regional.deliveryFeeZar, 180);
  assert.equal(regional.totalZar, 1020);
});

test('Google Play Console Asset Links validation and payload generation', () => {
  const validFp =
    'A1:B2:C3:D4:E5:F6:07:18:29:3A:4B:5C:6D:7E:8F:90:11:22:33:44:55:66:77:88:99:AA:BB:CC:DD:EE:FF:00';
  assert.equal(isValidAndroidPackageName('com.papioopulentus.client'), true);
  assert.equal(isValidAndroidPackageName('invalid_pkg'), false);
  assert.equal(isValidSha256Fingerprint(validFp), true);
  assert.equal(isValidSha256Fingerprint('NOT:A:VALID:HASH'), false);
  assert.equal(isValidVerificationHtmlFilename('google8f4a2c91e0b3d712.html'), true);
  assert.equal(isValidVerificationHtmlFilename('../secret.txt'), false);

  const payload = buildAssetLinksPayload([
    {
      id: 'app-1',
      label: 'Papio Client App',
      packageName: 'com.papioopulentus.client',
      sha256Fingerprints: [validFp.toLowerCase()],
      relations: ['delegate_permission/common.handle_all_urls'],
      enabled: true,
    },
    {
      id: 'app-disabled',
      label: 'Disabled App',
      packageName: 'com.papioopulentus.driver',
      sha256Fingerprints: [validFp],
      relations: ['delegate_permission/common.handle_all_urls'],
      enabled: false,
    },
  ]);

  assert.equal(payload.length, 1);
  assert.equal(payload[0].target.package_name, 'com.papioopulentus.client');
  assert.equal(payload[0].target.sha256_cert_fingerprints[0], validFp);
});

test('formatZar formats South African Rand consistently', () => {
  const out = formatZar(1250.5);
  assert.ok(out.startsWith('R '));
  assert.ok(out.includes('1'));
  assert.ok(out.includes('250'));
});
