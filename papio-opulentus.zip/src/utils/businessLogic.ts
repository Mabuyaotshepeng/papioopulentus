import type {
  AssetLinkApp,
  FarmOrderLine,
  VehicleClass,
} from '../types/domain';

export interface MicroloanCalculation {
  principalZar: number;
  termMonths: number;
  monthlyRatePct: number;
  initiationFeeZar: number;
  monthlyInstallmentZar: number;
  totalInterestZar: number;
  totalRepayableZar: number;
  debtToIncomePct: number;
  recommendedEligible: boolean;
}

export function calculateMicroloan(
  principalZar: number,
  termMonths: number,
  monthlyRatePct = 3.5,
  monthlyIncomeZar = 0
): MicroloanCalculation {
  const safePrincipal = Math.max(500, Math.min(50000, Math.round(principalZar)));
  const safeTerm = Math.max(1, Math.min(24, Math.round(termMonths)));
  const safeRate = Math.max(0.5, Math.min(10, monthlyRatePct));

  const initiationFeeZar = Math.round(Math.min(1050, 165 + Math.max(0, safePrincipal - 1000) * 0.05));
  const totalInterestZar = Math.round(safePrincipal * (safeRate / 100) * safeTerm);
  const totalRepayableZar = safePrincipal + totalInterestZar + initiationFeeZar;
  const monthlyInstallmentZar = Math.round((totalRepayableZar / safeTerm) * 100) / 100;

  const debtToIncomePct =
    monthlyIncomeZar > 0
      ? Math.round((monthlyInstallmentZar / monthlyIncomeZar) * 1000) / 10
      : 0;

  const recommendedEligible =
    monthlyIncomeZar > 0 && debtToIncomePct <= 40 && safePrincipal >= 500;

  return {
    principalZar: safePrincipal,
    termMonths: safeTerm,
    monthlyRatePct: safeRate,
    initiationFeeZar,
    monthlyInstallmentZar,
    totalInterestZar,
    totalRepayableZar,
    debtToIncomePct,
    recommendedEligible,
  };
}

export interface RideFareEstimate {
  distanceKm: number;
  vehicleClass: VehicleClass;
  baseFareZar: number;
  perKmRateZar: number;
  estimatedFareZar: number;
  estimatedMinutes: number;
}

const VEHICLE_RATES: Record<VehicleClass, { base: number; perKm: number; speedKmh: number }> = {
  'Standard Sedan': { base: 35, perKm: 11.5, speedKmh: 58 },
  'Executive SUV': { base: 65, perKm: 16.0, speedKmh: 62 },
  'Farm Cargo Utility': { base: 85, perKm: 18.5, speedKmh: 52 },
};

export function calculateRideFare(
  distanceKm: number,
  vehicleClass: VehicleClass
): RideFareEstimate {
  const safeDistance = Math.max(1, Math.min(350, Math.round(distanceKm * 10) / 10));
  const tariff = VEHICLE_RATES[vehicleClass];
  const rawFare = tariff.base + safeDistance * tariff.perKm;
  const estimatedFareZar = Math.round(rawFare * 100) / 100;
  const estimatedMinutes = Math.max(6, Math.round((safeDistance / tariff.speedKmh) * 60 + 4));

  return {
    distanceKm: safeDistance,
    vehicleClass,
    baseFareZar: tariff.base,
    perKmRateZar: tariff.perKm,
    estimatedFareZar,
    estimatedMinutes,
  };
}

export function calculateFarmOrderTotal(
  lines: FarmOrderLine[],
  deliveryLocation: string
): { subtotalZar: number; deliveryFeeZar: number; totalZar: number } {
  const subtotalZar = Math.round(
    lines.reduce((sum, line) => sum + Math.max(0, line.quantity) * Math.max(0, line.unitPriceZar), 0) * 100
  ) / 100;

  if (subtotalZar === 0) {
    return { subtotalZar: 0, deliveryFeeZar: 0, totalZar: 0 };
  }

  const normalized = deliveryLocation.toLowerCase();
  const isLocalMoruleng =
    normalized.includes('moruleng') ||
    normalized.includes('lesobeng') ||
    normalized.includes('pickup');

  const deliveryFeeZar = isLocalMoruleng ? 0 : subtotalZar >= 3500 ? 0 : 180;
  const totalZar = Math.round((subtotalZar + deliveryFeeZar) * 100) / 100;

  return { subtotalZar, deliveryFeeZar, totalZar };
}

export function isValidAndroidPackageName(pkg: string): boolean {
  return /^[a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*)+$/.test(pkg.trim());
}

export function isValidSha256Fingerprint(fp: string): boolean {
  const cleaned = fp.trim().toUpperCase();
  return /^([0-9A-F]{2}:){31}[0-9A-F]{2}$/.test(cleaned);
}

export function isValidVerificationHtmlFilename(filename: string): boolean {
  const trimmed = filename.trim().replace(/^\/+/, '');
  return /^[a-zA-Z0-9._-]+\.html$/.test(trimmed);
}

export interface AssetLinkStatement {
  relation: string[];
  target: {
    namespace: 'android_app';
    package_name: string;
    sha256_cert_fingerprints: string[];
  };
}

export function buildAssetLinksPayload(apps: AssetLinkApp[]): AssetLinkStatement[] {
  return apps
    .filter((app) => app.enabled && isValidAndroidPackageName(app.packageName))
    .map((app) => ({
      relation:
        app.relations.length > 0
          ? app.relations
          : ['delegate_permission/common.handle_all_urls'],
      target: {
        namespace: 'android_app' as const,
        package_name: app.packageName.trim(),
        sha256_cert_fingerprints: app.sha256Fingerprints
          .map((fp) => fp.trim().toUpperCase())
          .filter((fp) => isValidSha256Fingerprint(fp)),
      },
    }))
    .filter((statement) => statement.target.sha256_cert_fingerprints.length > 0);
}

export function formatZar(amount: number): string {
  const formatted = new Intl.NumberFormat('en-ZA', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(amount);
  return `R ${formatted}`;
}

export function escapeHtmlAttr(value: string): string {
  return value
    .replace(/&/g, '&amp;')
    .replace(/"/g, '&quot;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
}
