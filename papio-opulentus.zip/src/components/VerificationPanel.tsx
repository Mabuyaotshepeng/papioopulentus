import { CheckCircle2, Copy, ExternalLink, Play, Plus, Trash2, XCircle } from 'lucide-react';
import { useMemo, useState } from 'react';
import type {
  VerificationConfig,
  VerificationProbeCheck,
} from '../types/domain';
import {
  buildAssetLinksPayload,
  isValidAndroidPackageName,
  isValidSha256Fingerprint,
  isValidVerificationHtmlFilename,
} from '../utils/businessLogic';

interface VerificationPanelProps {
  verification: VerificationConfig;
  onRefreshState: () => Promise<void>;
}

export function VerificationPanel({ verification, onRefreshState }: VerificationPanelProps) {
  const [draft, setDraft] = useState<VerificationConfig>(verification);
  const [saving, setSaving] = useState(false);
  const [saveMessage, setSaveMessage] = useState<{ type: 'ok' | 'err'; text: string } | null>(null);
  const [probing, setProbing] = useState(false);
  const [probeChecks, setProbeChecks] = useState<VerificationProbeCheck[] | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  // New Android Asset Link form
  const [newAppLabel, setNewAppLabel] = useState('');
  const [newPackageName, setNewPackageName] = useState('');
  const [newSha256, setNewSha256] = useState('');

  // New HTML Verification File form
  const [newHtmlProvider, setNewHtmlProvider] = useState('Google Search & Play Console');
  const [newHtmlFilename, setNewHtmlFilename] = useState('');

  // New Meta Tag form
  const [newMetaProvider, setNewMetaProvider] = useState('Google Site Verification');
  const [newMetaName, setNewMetaName] = useState('google-site-verification');
  const [newMetaContent, setNewMetaContent] = useState('');

  const liveAssetLinksJson = useMemo(
    () => JSON.stringify(buildAssetLinksPayload(draft.assetLinks), null, 2),
    [draft.assetLinks]
  );

  const persistConfig = async (nextConfig: VerificationConfig, successNote: string) => {
    setSaving(true);
    setSaveMessage(null);
    try {
      const res = await fetch('/api/verification', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(nextConfig),
      });
      const data = await res.json();
      if (!res.ok) {
        setSaveMessage({ type: 'err', text: data.error || 'Failed to save verification settings.' });
      } else {
        setDraft(data);
        await onRefreshState();
        setSaveMessage({ type: 'ok', text: successNote });
      }
    } catch {
      setSaveMessage({ type: 'err', text: 'Network error while saving verification settings.' });
    } finally {
      setSaving(false);
    }
  };

  const handleAddAndroidApp = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaveMessage(null);
    if (!isValidAndroidPackageName(newPackageName)) {
      setSaveMessage({
        type: 'err',
        text: 'Enter a valid Android package name (e.g. com.papioopulentus.driver).',
      });
      return;
    }
    if (!isValidSha256Fingerprint(newSha256)) {
      setSaveMessage({
        type: 'err',
        text: 'Enter a valid SHA-256 fingerprint (32 colon-separated hex pairs, e.g. 9A:4B:12:...).',
      });
      return;
    }

    const nextConfig: VerificationConfig = {
      ...draft,
      assetLinks: [
        ...draft.assetLinks,
        {
          id: `app-${Date.now()}`,
          label: newAppLabel.trim() || newPackageName.trim(),
          packageName: newPackageName.trim(),
          sha256Fingerprints: [newSha256.trim().toUpperCase()],
          relations: ['delegate_permission/common.handle_all_urls'],
          enabled: true,
        },
      ],
    };
    setNewAppLabel('');
    setNewPackageName('');
    setNewSha256('');
    await persistConfig(nextConfig, 'Google Play Console Digital Asset Link added and published.');
  };

  const handleAddHtmlFile = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaveMessage(null);
    const cleanFilename = newHtmlFilename.trim().replace(/^\/+/, '');
    if (!isValidVerificationHtmlFilename(cleanFilename)) {
      setSaveMessage({
        type: 'err',
        text: 'Enter a valid verification .html filename (e.g. google1a2b3c4d5e6f.html).',
      });
      return;
    }

    const expectedBody = cleanFilename.startsWith('google')
      ? `google-site-verification: ${cleanFilename}`
      : cleanFilename;

    const nextConfig: VerificationConfig = {
      ...draft,
      htmlFiles: [
        ...draft.htmlFiles,
        {
          id: `html-${Date.now()}`,
          provider: newHtmlProvider.trim() || 'External Verifier',
          filename: cleanFilename,
          content: expectedBody,
          enabled: true,
          updatedAt: new Date().toISOString(),
        },
      ],
    };
    setNewHtmlFilename('');
    await persistConfig(nextConfig, `Verification file /${cleanFilename} is now live.`);
  };

  const handleAddMetaTag = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaveMessage(null);
    if (!newMetaName.trim() || !newMetaContent.trim()) {
      setSaveMessage({ type: 'err', text: 'Enter both meta tag name and verification token content.' });
      return;
    }
    const nextConfig: VerificationConfig = {
      ...draft,
      metaTags: [
        ...draft.metaTags,
        {
          id: `meta-${Date.now()}`,
          provider: newMetaProvider.trim() || 'Custom Meta Verifier',
          metaName: newMetaName.trim(),
          metaContent: newMetaContent.trim(),
          enabled: true,
        },
      ],
    };
    setNewMetaContent('');
    await persistConfig(nextConfig, 'HTML <meta> verification tag injected into live document head.');
  };

  const handleRunProbe = async () => {
    setProbing(true);
    try {
      const res = await fetch('/api/verification/probe', { method: 'POST' });
      const data = await res.json();
      setProbeChecks(data.checks || []);
    } catch {
      setProbeChecks([
        {
          id: 'probe-err',
          label: 'Verification Probe',
          endpoint: '/api/verification/probe',
          ok: false,
          statusCode: 0,
          contentType: 'error',
          preview: 'Unable to reach verification probe endpoint.',
        },
      ]);
    } finally {
      setProbing(false);
    }
  };

  const copyText = (id: string, value: string) => {
    navigator.clipboard?.writeText(value);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 1800);
  };

  return (
    <div className="space-y-8">
      {/* Header & Live Endpoint Probe */}
      <div className="bg-white border border-stone-200 rounded-xl p-6">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div>
            <h2 className="font-display text-lg font-bold text-stone-900">
              External Domain &amp; Google Play Console Verification
            </h2>
            <p className="mt-1 text-sm text-stone-600">
              Publish live <code className="font-mono text-xs bg-stone-100 px-1.5 py-0.5 rounded">/.well-known/assetlinks.json</code>, Google HTML verification files, and <code className="font-mono text-xs bg-stone-100 px-1.5 py-0.5 rounded">&lt;meta&gt;</code> tags directly from your server.
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-3 shrink-0">
            <a
              href="/.well-known/assetlinks.json"
              target="_blank"
              rel="noreferrer"
              className="inline-flex items-center gap-1.5 px-3.5 py-2 border border-stone-300 bg-white text-stone-800 text-xs font-semibold rounded-lg hover:bg-stone-50 whitespace-nowrap shrink-0"
            >
              View Live assetlinks.json
              <ExternalLink className="h-3.5 w-3.5" />
            </a>
            <button
              type="button"
              onClick={handleRunProbe}
              disabled={probing}
              className="inline-flex items-center gap-1.5 px-4 py-2 bg-[#14532D] text-white text-xs font-semibold rounded-lg hover:bg-[#114224] disabled:opacity-60 whitespace-nowrap shrink-0 cursor-pointer"
            >
              <Play className="h-3.5 w-3.5" />
              {probing ? 'Running Live Check...' : 'Run Live Endpoint Check'}
            </button>
          </div>
        </div>

        {saveMessage && (
          <div
            role="status"
            className={`mt-4 rounded-lg border p-3 text-xs ${
              saveMessage.type === 'ok'
                ? 'border-emerald-200 bg-emerald-50 text-emerald-900'
                : 'border-red-200 bg-red-50 text-red-900'
            }`}
          >
            {saveMessage.text}
          </div>
        )}

        {probeChecks && (
          <div className="mt-6 border-t border-stone-200 pt-5 space-y-3">
            <p className="text-xs font-semibold text-stone-700">Live Server Verification Probe Results</p>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {probeChecks.map((check) => (
                <div
                  key={check.id}
                  className="border border-stone-200 rounded-lg p-3.5 bg-stone-50 text-xs"
                >
                  <div className="flex items-center justify-between gap-2">
                    <span className="font-semibold text-stone-900">{check.label}</span>
                    <span
                      className={`inline-flex items-center gap-1 font-mono font-semibold ${
                        check.ok ? 'text-emerald-700' : 'text-red-700'
                      }`}
                    >
                      {check.ok ? (
                        <CheckCircle2 className="h-3.5 w-3.5" />
                      ) : (
                        <XCircle className="h-3.5 w-3.5" />
                      )}
                      HTTP {check.statusCode}
                    </span>
                  </div>
                  <p className="mt-1 font-mono text-[11px] text-stone-500">
                    {check.endpoint} · {check.contentType}
                  </p>
                  <pre className="mt-2 p-2.5 rounded bg-white border border-stone-200 font-mono text-[11px] text-stone-700 overflow-x-auto whitespace-pre max-h-40">
                    {check.preview}
                  </pre>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* 1. Google Play Console Digital Asset Links */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        <div className="lg:col-span-7 bg-white border border-stone-200 rounded-xl p-6">
          <h3 className="font-display text-base font-bold text-stone-900">
            01. Google Play Console — Android App Links (assetlinks.json)
          </h3>
          <p className="mt-1 text-xs text-stone-500">
            Verify ownership between this website and your Android apps in Google Play Console App Integrity / Deep Links.
          </p>

          <div className="mt-4 space-y-3">
            {draft.assetLinks.map((app) => (
              <div key={app.id} className="border border-stone-200 rounded-lg p-4 flex flex-col gap-2">
                <div className="flex items-center justify-between gap-3">
                  <div>
                    <p className="text-sm font-semibold text-stone-900">{app.label}</p>
                    <p className="font-mono text-xs text-stone-600">{app.packageName}</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => {
                        const updated = {
                          ...draft,
                          assetLinks: draft.assetLinks.map((a) =>
                            a.id === app.id ? { ...a, enabled: !a.enabled } : a
                          ),
                        };
                        persistConfig(updated, `${app.packageName} ${app.enabled ? 'disabled' : 'enabled'}.`);
                      }}
                      className={`px-2.5 py-1 text-xs font-medium rounded border cursor-pointer ${
                        app.enabled
                          ? 'border-emerald-300 bg-emerald-50 text-emerald-800'
                          : 'border-stone-300 bg-stone-100 text-stone-600'
                      }`}
                    >
                      {app.enabled ? 'Active' : 'Paused'}
                    </button>
                    <button
                      type="button"
                      aria-label={`Remove ${app.packageName}`}
                      onClick={() => {
                        const updated = {
                          ...draft,
                          assetLinks: draft.assetLinks.filter((a) => a.id !== app.id),
                        };
                        persistConfig(updated, `Removed ${app.packageName} from assetlinks.json.`);
                      }}
                      className="p-1.5 text-stone-400 hover:text-red-600 cursor-pointer"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                </div>
                <p className="font-mono text-[11px] text-stone-500 break-all">
                  SHA-256: {app.sha256Fingerprints.join(', ')}
                </p>
              </div>
            ))}
          </div>

          <form onSubmit={handleAddAndroidApp} className="mt-6 pt-5 border-t border-stone-200 space-y-3">
            <p className="text-xs font-semibold text-stone-900">Add Android App Fingerprint</p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label htmlFor="al-label" className="block text-xs text-stone-600">
                  App Label
                </label>
                <input
                  id="al-label"
                  type="text"
                  value={newAppLabel}
                  onChange={(e) => setNewAppLabel(e.target.value)}
                  placeholder="e.g. Papio Driver App"
                  className="mt-1 w-full rounded-lg border border-stone-300 px-3 py-2 text-xs focus:border-[#14532D] focus:outline-none"
                />
              </div>
              <div>
                <label htmlFor="al-package" className="block text-xs text-stone-600">
                  Android Package Name
                </label>
                <input
                  id="al-package"
                  type="text"
                  value={newPackageName}
                  onChange={(e) => setNewPackageName(e.target.value)}
                  placeholder="com.papioopulentus.driver"
                  className="mt-1 w-full rounded-lg border border-stone-300 px-3 py-2 text-xs font-mono focus:border-[#14532D] focus:outline-none"
                />
              </div>
            </div>
            <div>
              <label htmlFor="al-sha256" className="block text-xs text-stone-600">
                Play Console App Signing SHA-256 Certificate Fingerprint
              </label>
              <input
                id="al-sha256"
                type="text"
                value={newSha256}
                onChange={(e) => setNewSha256(e.target.value)}
                placeholder="11:22:33:44:55:66:77:88:99:AA:BB:CC:DD:EE:FF:00:11:22:33:44:55:66:77:88:99:AA:BB:CC:DD:EE:FF:00"
                className="mt-1 w-full rounded-lg border border-stone-300 px-3 py-2 text-xs font-mono focus:border-[#14532D] focus:outline-none"
              />
            </div>
            <button
              type="submit"
              disabled={saving}
              className="inline-flex items-center gap-1.5 px-4 py-2 bg-stone-900 text-white text-xs font-semibold rounded-lg hover:bg-[#14532D] transition-colors cursor-pointer"
            >
              <Plus className="h-3.5 w-3.5" />
              Save Play Console App Link
            </button>
          </form>
        </div>

        <div className="lg:col-span-5 bg-[#111827] text-stone-100 border border-stone-800 rounded-xl p-6">
          <div className="flex items-center justify-between gap-2">
            <span className="font-mono text-xs text-stone-300">/.well-known/assetlinks.json</span>
            <button
              type="button"
              onClick={() => copyText('assetlinks-json', liveAssetLinksJson)}
              className="inline-flex items-center gap-1 px-2.5 py-1 rounded bg-white/10 hover:bg-white/20 text-xs text-white cursor-pointer"
            >
              <Copy className="h-3 w-3" />
              {copiedId === 'assetlinks-json' ? 'Copied' : 'Copy JSON'}
            </button>
          </div>
          <pre className="mt-4 font-mono text-xs text-emerald-300 overflow-x-auto leading-relaxed">
            {liveAssetLinksJson}
          </pre>
        </div>
      </div>

      {/* 2. HTML Verification Files & Meta Tags */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* HTML Verification Files */}
        <div className="bg-white border border-stone-200 rounded-xl p-6">
          <h3 className="font-display text-base font-bold text-stone-900">
            02. Google HTML Verification Files
          </h3>
          <p className="mt-1 text-xs text-stone-500">
            Serve exact <code className="font-mono">google*.html</code> verification files requested by Google Search Console or Play Console developer domain check.
          </p>

          <ul className="mt-4 space-y-2.5">
            {draft.htmlFiles.map((file) => (
              <li
                key={file.id}
                className="border border-stone-200 rounded-lg p-3 flex items-center justify-between gap-3 text-xs"
              >
                <div className="min-w-0">
                  <p className="font-semibold text-stone-900">{file.provider}</p>
                  <a
                    href={`/${file.filename}`}
                    target="_blank"
                    rel="noreferrer"
                    className="font-mono text-[#14532D] hover:underline truncate block"
                  >
                    /{file.filename}
                  </a>
                </div>
                <div className="flex items-center gap-2 shrink-0">
                  <button
                    type="button"
                    onClick={() => {
                      const updated = {
                        ...draft,
                        htmlFiles: draft.htmlFiles.map((f) =>
                          f.id === file.id ? { ...f, enabled: !f.enabled } : f
                        ),
                      };
                      persistConfig(updated, `/${file.filename} updated.`);
                    }}
                    className={`px-2 py-1 rounded border text-[11px] font-medium cursor-pointer ${
                      file.enabled
                        ? 'border-emerald-300 bg-emerald-50 text-emerald-800'
                        : 'border-stone-300 bg-stone-100 text-stone-600'
                    }`}
                  >
                    {file.enabled ? 'Served' : 'Disabled'}
                  </button>
                  <button
                    type="button"
                    aria-label={`Delete ${file.filename}`}
                    onClick={() => {
                      const updated = {
                        ...draft,
                        htmlFiles: draft.htmlFiles.filter((f) => f.id !== file.id),
                      };
                      persistConfig(updated, `Removed /${file.filename}.`);
                    }}
                    className="p-1 text-stone-400 hover:text-red-600 cursor-pointer"
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                  </button>
                </div>
              </li>
            ))}
          </ul>

          <form onSubmit={handleAddHtmlFile} className="mt-5 pt-4 border-t border-stone-200 space-y-3">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label htmlFor="html-provider" className="block text-xs text-stone-600">
                  Verifier Platform
                </label>
                <input
                  id="html-provider"
                  type="text"
                  value={newHtmlProvider}
                  onChange={(e) => setNewHtmlProvider(e.target.value)}
                  className="mt-1 w-full rounded-lg border border-stone-300 px-3 py-2 text-xs focus:border-[#14532D] focus:outline-none"
                />
              </div>
              <div>
                <label htmlFor="html-filename" className="block text-xs text-stone-600">
                  Verification HTML Filename
                </label>
                <input
                  id="html-filename"
                  type="text"
                  value={newHtmlFilename}
                  onChange={(e) => setNewHtmlFilename(e.target.value)}
                  placeholder="google9b2e1f4c8a7d0011.html"
                  className="mt-1 w-full rounded-lg border border-stone-300 px-3 py-2 text-xs font-mono focus:border-[#14532D] focus:outline-none"
                />
              </div>
            </div>
            <button
              type="submit"
              disabled={saving}
              className="inline-flex items-center gap-1.5 px-4 py-2 bg-stone-900 text-white text-xs font-semibold rounded-lg hover:bg-[#14532D] cursor-pointer"
            >
              <Plus className="h-3.5 w-3.5" />
              Publish HTML Verification File
            </button>
          </form>
        </div>

        {/* HTML Meta Verification Tags */}
        <div className="bg-white border border-stone-200 rounded-xl p-6">
          <h3 className="font-display text-base font-bold text-stone-900">
            03. HTML &lt;meta&gt; Verification Tags &amp; DNS TXT
          </h3>
          <p className="mt-1 text-xs text-stone-500">
            Automatically injected into the live <code className="font-mono">&lt;head&gt;</code> on every page request.
          </p>

          <ul className="mt-4 space-y-2.5">
            {draft.metaTags.map((tag) => (
              <li
                key={tag.id}
                className="border border-stone-200 rounded-lg p-3 flex items-center justify-between gap-3 text-xs"
              >
                <div className="min-w-0">
                  <p className="font-semibold text-stone-900">{tag.provider}</p>
                  <p className="font-mono text-[11px] text-stone-600 truncate">
                    &lt;meta name=&quot;{tag.metaName}&quot; content=&quot;{tag.metaContent}&quot; /&gt;
                  </p>
                </div>
                <div className="flex items-center gap-2 shrink-0">
                  <button
                    type="button"
                    onClick={() => {
                      const updated = {
                        ...draft,
                        metaTags: draft.metaTags.map((t) =>
                          t.id === tag.id ? { ...t, enabled: !t.enabled } : t
                        ),
                      };
                      persistConfig(updated, `Meta tag ${tag.metaName} updated.`);
                    }}
                    className={`px-2 py-1 rounded border text-[11px] font-medium cursor-pointer ${
                      tag.enabled
                        ? 'border-emerald-300 bg-emerald-50 text-emerald-800'
                        : 'border-stone-300 bg-stone-100 text-stone-600'
                    }`}
                  >
                    {tag.enabled ? 'Injected' : 'Disabled'}
                  </button>
                  <button
                    type="button"
                    aria-label={`Delete meta tag ${tag.metaName}`}
                    onClick={() => {
                      const updated = {
                        ...draft,
                        metaTags: draft.metaTags.filter((t) => t.id !== tag.id),
                      };
                      persistConfig(updated, `Removed meta tag ${tag.metaName}.`);
                    }}
                    className="p-1 text-stone-400 hover:text-red-600 cursor-pointer"
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                  </button>
                </div>
              </li>
            ))}
          </ul>

          <form onSubmit={handleAddMetaTag} className="mt-5 pt-4 border-t border-stone-200 space-y-3">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
              <div>
                <label htmlFor="meta-provider" className="block text-xs text-stone-600">
                  Provider
                </label>
                <input
                  id="meta-provider"
                  type="text"
                  value={newMetaProvider}
                  onChange={(e) => setNewMetaProvider(e.target.value)}
                  className="mt-1 w-full rounded-lg border border-stone-300 px-2.5 py-2 text-xs focus:border-[#14532D] focus:outline-none"
                />
              </div>
              <div>
                <label htmlFor="meta-name" className="block text-xs text-stone-600">
                  Meta Name
                </label>
                <input
                  id="meta-name"
                  type="text"
                  value={newMetaName}
                  onChange={(e) => setNewMetaName(e.target.value)}
                  className="mt-1 w-full rounded-lg border border-stone-300 px-2.5 py-2 text-xs font-mono focus:border-[#14532D] focus:outline-none"
                />
              </div>
              <div>
                <label htmlFor="meta-token" className="block text-xs text-stone-600">
                  Token Value
                </label>
                <input
                  id="meta-token"
                  type="text"
                  value={newMetaContent}
                  onChange={(e) => setNewMetaContent(e.target.value)}
                  placeholder="Verification token"
                  className="mt-1 w-full rounded-lg border border-stone-300 px-2.5 py-2 text-xs font-mono focus:border-[#14532D] focus:outline-none"
                />
              </div>
            </div>
            <button
              type="submit"
              disabled={saving}
              className="inline-flex items-center gap-1.5 px-4 py-2 bg-stone-900 text-white text-xs font-semibold rounded-lg hover:bg-[#14532D] cursor-pointer"
            >
              <Plus className="h-3.5 w-3.5" />
              Inject Meta Tag
            </button>
          </form>

          <div className="mt-5 pt-4 border-t border-stone-200 flex items-center justify-between gap-3">
            <div className="min-w-0">
              <p className="text-xs font-semibold text-stone-800">DNS TXT Verification Record</p>
              <p className="font-mono text-[11px] text-stone-500 truncate">{draft.dnsTxtToken}</p>
            </div>
            <button
              type="button"
              onClick={() => copyText('dns-txt', draft.dnsTxtToken)}
              className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg border border-stone-300 text-xs font-medium text-stone-700 hover:bg-stone-50 shrink-0 cursor-pointer"
            >
              <Copy className="h-3.5 w-3.5" />
              {copiedId === 'dns-txt' ? 'Copied' : 'Copy TXT'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
