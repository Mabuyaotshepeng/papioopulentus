import { Car, CheckCircle2, Landmark, Minus, Plus, Sprout, Trash2 } from 'lucide-react';
import { useMemo, useState } from 'react';
import type {
  AppStatePayload,
  FarmCategory,
  LoanPurpose,
  VehicleClass,
} from '../types/domain';
import {
  calculateFarmOrderTotal,
  calculateMicroloan,
  calculateRideFare,
  formatZar,
} from '../utils/businessLogic';

export type PortalTab = 'farm' | 'ehailing' | 'microlending' | 'requests';

interface ClientPortalProps {
  state: AppStatePayload;
  activeTab: PortalTab;
  onChangeTab: (tab: PortalTab) => void;
  onRefreshState: () => Promise<void>;
}

const ROUTE_PRESETS = [
  { label: 'Moruleng Village → Sun City Main Gate', pickup: 'Moruleng Village', dropoff: 'Sun City Main Gate', km: 18 },
  { label: 'Lesobeng Farm → Mogwase Shopping Centre', pickup: 'Lesobeng Farm Gate', dropoff: 'Mogwase Shopping Centre', km: 14 },
  { label: 'Moruleng Village → Rustenburg CBD', pickup: 'Moruleng Village', dropoff: 'Rustenburg CBD', km: 56 },
  { label: 'Sun City Resort → Pilanesberg Airport', pickup: 'Sun City Resort', dropoff: 'Pilanesberg International Airport', km: 11 },
];

export function ClientPortal({
  state,
  activeTab,
  onChangeTab,
  onRefreshState,
}: ClientPortalProps) {
  // Farm Store State
  const [farmFilter, setFarmFilter] = useState<'all' | FarmCategory>('all');
  const [cart, setCart] = useState<Record<string, number>>({});
  const [orderClientName, setOrderClientName] = useState('');
  const [orderClientPhone, setOrderClientPhone] = useState('');
  const [orderLocation, setOrderLocation] = useState('Moruleng Village');
  const [farmMessage, setFarmMessage] = useState<{ type: 'ok' | 'err'; text: string } | null>(null);
  const [farmSubmitting, setFarmSubmitting] = useState(false);

  // E-Hailing State
  const [passengerName, setPassengerName] = useState('');
  const [passengerPhone, setPassengerPhone] = useState('');
  const [pickupLocation, setPickupLocation] = useState('Moruleng Village');
  const [dropoffLocation, setDropoffLocation] = useState('Sun City Main Gate');
  const [distanceKm, setDistanceKm] = useState(18);
  const [vehicleClass, setVehicleClass] = useState<VehicleClass>('Standard Sedan');
  const [rideMessage, setRideMessage] = useState<{ type: 'ok' | 'err'; text: string } | null>(null);
  const [rideSubmitting, setRideSubmitting] = useState(false);

  // Microlending State
  const [applicantName, setApplicantName] = useState('');
  const [applicantPhone, setApplicantPhone] = useState('');
  const [nationalIdLast4, setNationalIdLast4] = useState('');
  const [monthlyIncomeZar, setMonthlyIncomeZar] = useState(12000);
  const [principalZar, setPrincipalZar] = useState(5000);
  const [termMonths, setTermMonths] = useState(6);
  const [loanPurpose, setLoanPurpose] = useState<LoanPurpose>('Working Capital');
  const [loanMessage, setLoanMessage] = useState<{ type: 'ok' | 'err'; text: string } | null>(null);
  const [loanSubmitting, setLoanSubmitting] = useState(false);

  const visibleFarmItems = useMemo(() => {
    if (farmFilter === 'all') return state.farmItems;
    return state.farmItems.filter((item) => item.category === farmFilter);
  }, [state.farmItems, farmFilter]);

  const cartLines = useMemo(() => {
    return Object.entries(cart)
      .filter(([, qty]) => qty > 0)
      .map(([itemId, quantity]) => {
        const item = state.farmItems.find((i) => i.id === itemId);
        if (!item) return null;
        return {
          itemId: item.id,
          itemName: item.name,
          quantity,
          unitPriceZar: item.unitPriceZar,
        };
      })
      .filter((line): line is NonNullable<typeof line> => line !== null);
  }, [cart, state.farmItems]);

  const farmTotals = useMemo(
    () => calculateFarmOrderTotal(cartLines, orderLocation),
    [cartLines, orderLocation]
  );

  const fareEstimate = useMemo(
    () => calculateRideFare(distanceKm, vehicleClass),
    [distanceKm, vehicleClass]
  );

  const loanCalc = useMemo(
    () => calculateMicroloan(principalZar, termMonths, 3.5, monthlyIncomeZar),
    [principalZar, termMonths, monthlyIncomeZar]
  );

  const adjustCart = (itemId: string, delta: number, maxQty: number) => {
    setCart((prev) => {
      const nextQty = Math.max(0, Math.min(maxQty, (prev[itemId] || 0) + delta));
      if (nextQty === 0) {
        const copy = { ...prev };
        delete copy[itemId];
        return copy;
      }
      return { ...prev, [itemId]: nextQty };
    });
  };

  const handleSubmitFarmOrder = async (e: React.FormEvent) => {
    e.preventDefault();
    setFarmMessage(null);
    if (cartLines.length === 0) {
      setFarmMessage({ type: 'err', text: 'Select at least one crop or livestock item before ordering.' });
      return;
    }
    if (!orderClientName.trim() || !orderClientPhone.trim()) {
      setFarmMessage({ type: 'err', text: 'Enter your full name and contact phone number.' });
      return;
    }
    setFarmSubmitting(true);
    try {
      const res = await fetch('/api/farm/orders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          clientName: orderClientName,
          clientPhone: orderClientPhone,
          deliveryLocation: orderLocation,
          items: cartLines.map((l) => ({ itemId: l.itemId, quantity: l.quantity })),
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        setFarmMessage({ type: 'err', text: data.error || 'Could not place farm order.' });
      } else {
        setCart({});
        setOrderClientName('');
        setOrderClientPhone('');
        await onRefreshState();
        setFarmMessage({
          type: 'ok',
          text: `Order ${data.id} confirmed for ${formatZar(data.totalZar)}. Track status in My Requests.`,
        });
      }
    } catch {
      setFarmMessage({ type: 'err', text: 'Network error while submitting farm order.' });
    } finally {
      setFarmSubmitting(false);
    }
  };

  const handleSubmitRide = async (e: React.FormEvent) => {
    e.preventDefault();
    setRideMessage(null);
    if (!passengerName.trim() || !passengerPhone.trim()) {
      setRideMessage({ type: 'err', text: 'Enter passenger name and phone number.' });
      return;
    }
    if (!pickupLocation.trim() || !dropoffLocation.trim()) {
      setRideMessage({ type: 'err', text: 'Enter both pickup and drop-off locations.' });
      return;
    }
    setRideSubmitting(true);
    try {
      const res = await fetch('/api/ehailing/rides', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          passengerName,
          passengerPhone,
          pickupLocation,
          dropoffLocation,
          distanceKm,
          vehicleClass,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        setRideMessage({ type: 'err', text: data.error || 'Could not submit ride booking.' });
      } else {
        setPassengerName('');
        setPassengerPhone('');
        await onRefreshState();
        setRideMessage({
          type: 'ok',
          text: `Ride ${data.id} requested (${formatZar(data.estimatedFareZar)}). Dispatch will assign a driver shortly.`,
        });
      }
    } catch {
      setRideMessage({ type: 'err', text: 'Network error while requesting ride.' });
    } finally {
      setRideSubmitting(false);
    }
  };

  const handleSubmitLoan = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoanMessage(null);
    if (!applicantName.trim() || !applicantPhone.trim()) {
      setLoanMessage({ type: 'err', text: 'Enter applicant full name and phone number.' });
      return;
    }
    if (!/^\d{4}$/.test(nationalIdLast4.trim())) {
      setLoanMessage({ type: 'err', text: 'Enter the last 4 digits of your SA ID number.' });
      return;
    }
    setLoanSubmitting(true);
    try {
      const res = await fetch('/api/microlending/loans', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          applicantName,
          applicantPhone,
          nationalIdLast4: nationalIdLast4.trim(),
          monthlyIncomeZar,
          principalZar,
          termMonths,
          purpose: loanPurpose,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        setLoanMessage({ type: 'err', text: data.error || 'Could not submit loan application.' });
      } else {
        setApplicantName('');
        setApplicantPhone('');
        setNationalIdLast4('');
        await onRefreshState();
        setLoanMessage({
          type: 'ok',
          text: `Application ${data.id} for ${formatZar(data.principalZar)} submitted for review.`,
        });
      }
    } catch {
      setLoanMessage({ type: 'err', text: 'Network error while submitting loan application.' });
    } finally {
      setLoanSubmitting(false);
    }
  };

  const totalRequestCount = state.farmOrders.length + state.rides.length + state.loans.length;

  return (
    <main className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-10">
      <div className="flex flex-col xl:flex-row xl:items-end justify-between gap-6 pb-8 border-b border-stone-200">
        <div>
          <p className="text-xs font-medium text-stone-500">
            Papio Opulentus · Self-Service Client Portal
          </p>
          <h1 className="mt-2 font-display text-2xl sm:text-3xl font-bold tracking-tight text-stone-900">
            Order produce, book transport, or apply for credit.
          </h1>
        </div>

        {/* Interactive Segmented Tab Bar */}
        <div
          role="tablist"
          aria-label="Client portal services"
          className="inline-flex items-center gap-1 p-1 bg-stone-200/70 rounded-lg overflow-x-auto max-w-full shrink-0"
        >
          <button
            type="button"
            role="tab"
            aria-selected={activeTab === 'farm'}
            onClick={() => onChangeTab('farm')}
            className={`inline-flex items-center gap-2 px-3.5 py-2 text-xs sm:text-sm font-medium rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
              activeTab === 'farm'
                ? 'bg-white text-stone-900 shadow-sm'
                : 'text-stone-600 hover:text-stone-900'
            }`}
          >
            <Sprout className="h-4 w-4 text-[#14532D]" />
            Lesobeng Farm
          </button>
          <button
            type="button"
            role="tab"
            aria-selected={activeTab === 'ehailing'}
            onClick={() => onChangeTab('ehailing')}
            className={`inline-flex items-center gap-2 px-3.5 py-2 text-xs sm:text-sm font-medium rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
              activeTab === 'ehailing'
                ? 'bg-white text-stone-900 shadow-sm'
                : 'text-stone-600 hover:text-stone-900'
            }`}
          >
            <Car className="h-4 w-4 text-stone-700" />
            Book E-Hailing
          </button>
          <button
            type="button"
            role="tab"
            aria-selected={activeTab === 'microlending'}
            onClick={() => onChangeTab('microlending')}
            className={`inline-flex items-center gap-2 px-3.5 py-2 text-xs sm:text-sm font-medium rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
              activeTab === 'microlending'
                ? 'bg-white text-stone-900 shadow-sm'
                : 'text-stone-600 hover:text-stone-900'
            }`}
          >
            <Landmark className="h-4 w-4 text-amber-700" />
            Microlending
          </button>
          <button
            type="button"
            role="tab"
            aria-selected={activeTab === 'requests'}
            onClick={() => onChangeTab('requests')}
            className={`inline-flex items-center gap-2 px-3.5 py-2 text-xs sm:text-sm font-medium rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer tabular-nums ${
              activeTab === 'requests'
                ? 'bg-white text-stone-900 shadow-sm'
                : 'text-stone-600 hover:text-stone-900'
            }`}
          >
            My Requests ({totalRequestCount})
          </button>
        </div>
      </div>

      {/* TAB 1: LESOBENG FARM STORE */}
      {activeTab === 'farm' && (
        <section className="mt-8 grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          <div className="lg:col-span-8">
            <div className="flex flex-wrap items-center justify-between gap-4 mb-6">
              <div>
                <h2 className="font-display text-xl font-bold text-stone-900">
                  Lesobeng Farm Inventory — Moruleng Village
                </h2>
                <p className="text-sm text-stone-500">
                  Free delivery within Moruleng Village and Lesobeng Farm gate pickups.
                </p>
              </div>
              <div className="inline-flex items-center gap-1 p-1 bg-stone-200/70 rounded-lg">
                {(['all', 'crops', 'livestock'] as const).map((cat) => (
                  <button
                    key={cat}
                    type="button"
                    onClick={() => setFarmFilter(cat)}
                    className={`px-3 py-1.5 text-xs font-medium rounded-md capitalize transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                      farmFilter === cat
                        ? 'bg-white text-stone-900 shadow-sm'
                        : 'text-stone-600 hover:text-stone-900'
                    }`}
                  >
                    {cat === 'all' ? 'All Stock' : cat}
                  </button>
                ))}
              </div>
            </div>

            {visibleFarmItems.length === 0 ? (
              <div className="bg-white border border-stone-200 rounded-xl p-8 text-center text-sm text-stone-500">
                No items available in this category.
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {visibleFarmItems.map((item) => {
                  const inCart = cart[item.id] || 0;
                  return (
                    <div
                      key={item.id}
                      className="bg-white border border-stone-200 rounded-xl p-5 flex flex-col justify-between"
                    >
                      <div>
                        <div className="text-xs text-stone-500">
                          <span className="capitalize">{item.category}</span>
                          <span className="mx-1.5" aria-hidden="true">·</span>
                          <span>{item.locationSection}</span>
                        </div>
                        <h3 className="mt-1.5 font-display text-base font-bold text-stone-900">
                          {item.name}
                        </h3>
                        <p className="mt-1 text-xs text-stone-600">{item.varietyOrBreed}</p>
                      </div>

                      <div className="mt-5 pt-4 border-t border-stone-100 flex items-end justify-between gap-3">
                        <div>
                          <p className="font-mono text-base font-semibold text-stone-900 tabular-nums">
                            {formatZar(item.unitPriceZar)}
                          </p>
                          <p className="text-xs text-stone-500 tabular-nums">
                            per {item.unit} · {item.quantityAvailable} available
                          </p>
                        </div>

                        {inCart === 0 ? (
                          <button
                            type="button"
                            disabled={item.quantityAvailable === 0}
                            onClick={() => adjustCart(item.id, 1, item.quantityAvailable)}
                            aria-label={`Add ${item.name} to order`}
                            className="px-3.5 py-2 text-xs font-semibold rounded-lg bg-[#14532D] text-white hover:bg-[#114224] disabled:bg-stone-300 disabled:cursor-not-allowed transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                          >
                            {item.quantityAvailable === 0 ? 'Out of Stock' : 'Add to Order'}
                          </button>
                        ) : (
                          <div className="inline-flex items-center gap-2 border border-stone-300 rounded-lg p-1 bg-stone-50">
                            <button
                              type="button"
                              aria-label={`Decrease quantity of ${item.name}`}
                              onClick={() => adjustCart(item.id, -1, item.quantityAvailable)}
                              className="p-1.5 rounded hover:bg-stone-200 text-stone-700 cursor-pointer"
                            >
                              <Minus className="h-3.5 w-3.5" />
                            </button>
                            <span className="min-w-[2ch] text-center font-mono text-xs font-semibold tabular-nums">
                              {inCart}
                            </span>
                            <button
                              type="button"
                              aria-label={`Increase quantity of ${item.name}`}
                              onClick={() => adjustCart(item.id, 1, item.quantityAvailable)}
                              className="p-1.5 rounded hover:bg-stone-200 text-stone-700 cursor-pointer"
                            >
                              <Plus className="h-3.5 w-3.5" />
                            </button>
                          </div>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* Order Summary & Checkout Form */}
          <aside className="lg:col-span-4 bg-white border border-stone-200 rounded-xl p-6">
            <h3 className="font-display text-lg font-bold text-stone-900">
              Farm Order Request
            </h3>
            <p className="mt-1 text-xs text-stone-500">
              Submitted directly to Lesobeng Farm dispatch.
            </p>

            {cartLines.length === 0 ? (
              <p className="mt-6 py-6 border-y border-stone-100 text-sm text-stone-500 text-center">
                No items selected yet. Add crops or livestock from the catalog.
              </p>
            ) : (
              <ul className="mt-5 divide-y divide-stone-100 border-y border-stone-200">
                {cartLines.map((line) => (
                  <li key={line.itemId} className="py-3 flex items-center justify-between gap-3 text-sm">
                    <div className="min-w-0">
                      <p className="font-medium text-stone-900 truncate">{line.itemName}</p>
                      <p className="text-xs text-stone-500 tabular-nums">
                        {line.quantity} × {formatZar(line.unitPriceZar)}
                      </p>
                    </div>
                    <div className="flex items-center gap-2 shrink-0">
                      <span className="font-mono text-xs font-semibold text-stone-900 tabular-nums">
                        {formatZar(line.quantity * line.unitPriceZar)}
                      </span>
                      <button
                        type="button"
                        aria-label={`Remove ${line.itemName} from order`}
                        onClick={() => adjustCart(line.itemId, -line.quantity, 9999)}
                        className="p-1 text-stone-400 hover:text-red-600 cursor-pointer"
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                      </button>
                    </div>
                  </li>
                ))}
              </ul>
            )}

            <dl className="mt-4 space-y-2 text-sm">
              <div className="flex justify-between text-stone-600">
                <dt>Subtotal</dt>
                <dd className="font-mono tabular-nums">{formatZar(farmTotals.subtotalZar)}</dd>
              </div>
              <div className="flex justify-between text-stone-600">
                <dt>Delivery Fee</dt>
                <dd className="font-mono tabular-nums">
                  {farmTotals.deliveryFeeZar === 0 ? 'Free' : formatZar(farmTotals.deliveryFeeZar)}
                </dd>
              </div>
              <div className="flex justify-between pt-2 border-t border-stone-200 font-bold text-stone-900">
                <dt>Total (ZAR)</dt>
                <dd className="font-mono tabular-nums">{formatZar(farmTotals.totalZar)}</dd>
              </div>
            </dl>

            <form onSubmit={handleSubmitFarmOrder} className="mt-6 space-y-4">
              <div>
                <label htmlFor="farm-client-name" className="block text-xs font-medium text-stone-700">
                  Full Name or Business Name
                </label>
                <input
                  id="farm-client-name"
                  type="text"
                  value={orderClientName}
                  onChange={(e) => setOrderClientName(e.target.value)}
                  placeholder="e.g. Kgosi Fresh Market"
                  className="mt-1 w-full rounded-lg border border-stone-300 px-3 py-2 text-sm focus:border-[#14532D] focus:outline-none"
                />
              </div>
              <div>
                <label htmlFor="farm-client-phone" className="block text-xs font-medium text-stone-700">
                  Contact Phone Number
                </label>
                <input
                  id="farm-client-phone"
                  type="tel"
                  value={orderClientPhone}
                  onChange={(e) => setOrderClientPhone(e.target.value)}
                  placeholder="+27 82 000 0000"
                  className="mt-1 w-full rounded-lg border border-stone-300 px-3 py-2 text-sm focus:border-[#14532D] focus:outline-none"
                />
              </div>
              <div>
                <label htmlFor="farm-delivery-loc" className="block text-xs font-medium text-stone-700">
                  Delivery / Pickup Location
                </label>
                <select
                  id="farm-delivery-loc"
                  value={orderLocation}
                  onChange={(e) => setOrderLocation(e.target.value)}
                  className="mt-1 w-full rounded-lg border border-stone-300 px-3 py-2 text-sm bg-white focus:border-[#14532D] focus:outline-none"
                >
                  <option value="Moruleng Village">Moruleng Village (Free Delivery)</option>
                  <option value="Lesobeng Farm Gate Pickup">Lesobeng Farm Gate Pickup (Free)</option>
                  <option value="Mogwase">Mogwase (R 180 / Free over R 3,500)</option>
                  <option value="Rustenburg CBD">Rustenburg CBD (R 180 / Free over R 3,500)</option>
                </select>
              </div>

              {farmMessage && (
                <div
                  role="status"
                  className={`rounded-lg border p-3 text-xs ${
                    farmMessage.type === 'ok'
                      ? 'border-emerald-200 bg-emerald-50 text-emerald-900'
                      : 'border-red-200 bg-red-50 text-red-900'
                  }`}
                >
                  {farmMessage.text}
                </div>
              )}

              <button
                type="submit"
                disabled={farmSubmitting}
                className="w-full py-2.5 px-4 bg-[#14532D] text-white text-sm font-semibold rounded-lg hover:bg-[#114224] disabled:opacity-60 transition-colors cursor-pointer"
              >
                {farmSubmitting ? 'Submitting Order...' : 'Submit Farm Order'}
              </button>
            </form>
          </aside>
        </section>
      )}

      {/* TAB 2: E-HAILING BOOKING */}
      {activeTab === 'ehailing' && (
        <section className="mt-8 grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          <div className="lg:col-span-7 bg-white border border-stone-200 rounded-xl p-6 sm:p-8">
            <h2 className="font-display text-xl font-bold text-stone-900">
              Request Papio E-Hailing Transport
            </h2>
            <p className="mt-1 text-sm text-stone-500">
              Choose a common route preset or customize pickup, destination, and vehicle class.
            </p>

            <div className="mt-5">
              <p className="text-xs font-medium text-stone-600 mb-2">Quick Route Presets</p>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {ROUTE_PRESETS.map((preset) => (
                  <button
                    key={preset.label}
                    type="button"
                    onClick={() => {
                      setPickupLocation(preset.pickup);
                      setDropoffLocation(preset.dropoff);
                      setDistanceKm(preset.km);
                    }}
                    className="text-left p-3 rounded-lg border border-stone-200 hover:border-[#14532D] hover:bg-stone-50 transition-colors text-xs cursor-pointer"
                  >
                    <span className="font-semibold text-stone-900 block">{preset.label}</span>
                    <span className="text-stone-500 tabular-nums">{preset.km} km corridor</span>
                  </button>
                ))}
              </div>
            </div>

            <form onSubmit={handleSubmitRide} className="mt-6 space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label htmlFor="ride-passenger-name" className="block text-xs font-medium text-stone-700">
                    Passenger Full Name
                  </label>
                  <input
                    id="ride-passenger-name"
                    type="text"
                    value={passengerName}
                    onChange={(e) => setPassengerName(e.target.value)}
                    placeholder="e.g. Karabo Modise"
                    className="mt-1 w-full rounded-lg border border-stone-300 px-3 py-2 text-sm focus:border-[#14532D] focus:outline-none"
                  />
                </div>
                <div>
                  <label htmlFor="ride-passenger-phone" className="block text-xs font-medium text-stone-700">
                    Mobile Phone
                  </label>
                  <input
                    id="ride-passenger-phone"
                    type="tel"
                    value={passengerPhone}
                    onChange={(e) => setPassengerPhone(e.target.value)}
                    placeholder="+27 72 000 0000"
                    className="mt-1 w-full rounded-lg border border-stone-300 px-3 py-2 text-sm focus:border-[#14532D] focus:outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label htmlFor="ride-pickup" className="block text-xs font-medium text-stone-700">
                    Pickup Location
                  </label>
                  <input
                    id="ride-pickup"
                    type="text"
                    value={pickupLocation}
                    onChange={(e) => setPickupLocation(e.target.value)}
                    className="mt-1 w-full rounded-lg border border-stone-300 px-3 py-2 text-sm focus:border-[#14532D] focus:outline-none"
                  />
                </div>
                <div>
                  <label htmlFor="ride-dropoff" className="block text-xs font-medium text-stone-700">
                    Drop-off Destination
                  </label>
                  <input
                    id="ride-dropoff"
                    type="text"
                    value={dropoffLocation}
                    onChange={(e) => setDropoffLocation(e.target.value)}
                    className="mt-1 w-full rounded-lg border border-stone-300 px-3 py-2 text-sm focus:border-[#14532D] focus:outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label htmlFor="ride-distance" className="block text-xs font-medium text-stone-700">
                    Estimated Distance (km)
                  </label>
                  <input
                    id="ride-distance"
                    type="number"
                    min={1}
                    max={350}
                    value={distanceKm}
                    onChange={(e) => setDistanceKm(Number(e.target.value) || 1)}
                    className="mt-1 w-full rounded-lg border border-stone-300 px-3 py-2 text-sm font-mono tabular-nums focus:border-[#14532D] focus:outline-none"
                  />
                </div>
                <div>
                  <label htmlFor="ride-vehicle-class" className="block text-xs font-medium text-stone-700">
                    Vehicle Class
                  </label>
                  <select
                    id="ride-vehicle-class"
                    value={vehicleClass}
                    onChange={(e) => setVehicleClass(e.target.value as VehicleClass)}
                    className="mt-1 w-full rounded-lg border border-stone-300 px-3 py-2 text-sm bg-white focus:border-[#14532D] focus:outline-none"
                  >
                    <option value="Standard Sedan">Standard Sedan (4 Pax)</option>
                    <option value="Executive SUV">Executive SUV (6 Pax)</option>
                    <option value="Farm Cargo Utility">Farm Cargo Utility (Light Freight)</option>
                  </select>
                </div>
              </div>

              {rideMessage && (
                <div
                  role="status"
                  className={`rounded-lg border p-3 text-xs ${
                    rideMessage.type === 'ok'
                      ? 'border-emerald-200 bg-emerald-50 text-emerald-900'
                      : 'border-red-200 bg-red-50 text-red-900'
                  }`}
                >
                  {rideMessage.text}
                </div>
              )}

              <button
                type="submit"
                disabled={rideSubmitting}
                className="px-6 py-3 bg-[#14532D] text-white text-sm font-semibold rounded-lg hover:bg-[#114224] disabled:opacity-60 transition-colors cursor-pointer"
              >
                {rideSubmitting ? 'Booking Ride...' : 'Confirm Ride Request'}
              </button>
            </form>
          </div>

          <aside className="lg:col-span-5 bg-white border border-stone-200 rounded-xl p-6 sm:p-8 space-y-6">
            <div>
              <p className="text-xs font-medium text-stone-500">Live Fare Quote</p>
              <p className="mt-2 font-display text-3xl font-bold text-stone-900 font-mono tabular-nums">
                {formatZar(fareEstimate.estimatedFareZar)}
              </p>
              <p className="mt-1 text-xs text-stone-500 tabular-nums">
                Est. travel time: {fareEstimate.estimatedMinutes} min · {fareEstimate.distanceKm} km ({fareEstimate.vehicleClass})
              </p>
            </div>

            <dl className="space-y-2 pt-4 border-t border-stone-200 text-sm">
              <div className="flex justify-between text-stone-600">
                <dt>Base Flagfall</dt>
                <dd className="font-mono tabular-nums">{formatZar(fareEstimate.baseFareZar)}</dd>
              </div>
              <div className="flex justify-between text-stone-600">
                <dt>Distance Tariff ({fareEstimate.distanceKm} km × {formatZar(fareEstimate.perKmRateZar)})</dt>
                <dd className="font-mono tabular-nums">
                  {formatZar(fareEstimate.distanceKm * fareEstimate.perKmRateZar)}
                </dd>
              </div>
            </dl>

            <div className="pt-4 border-t border-stone-200">
              <h3 className="text-xs font-semibold text-stone-900">Active Fleet Drivers Nearby</h3>
              <ul className="mt-3 space-y-2.5">
                {state.drivers.filter((d) => d.available).map((driver) => (
                  <li key={driver.id} className="text-xs flex items-center justify-between gap-2 text-stone-600">
                    <div>
                      <span className="font-semibold text-stone-900">{driver.fullName}</span>
                      <span className="mx-1.5" aria-hidden="true">·</span>
                      <span>{driver.vehicleModel}</span>
                    </div>
                    <span className="font-mono text-stone-500 shrink-0">{driver.vehicleClass}</span>
                  </li>
                ))}
              </ul>
            </div>
          </aside>
        </section>
      )}

      {/* TAB 3: MICROLENDING CALCULATOR & APPLICATION */}
      {activeTab === 'microlending' && (
        <section className="mt-8 grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          <div className="lg:col-span-7 bg-white border border-stone-200 rounded-xl p-6 sm:p-8">
            <h2 className="font-display text-xl font-bold text-stone-900">
              Microloan Application — Papio Opulentus Credit
            </h2>
            <p className="mt-1 text-sm text-stone-500">
              Transparent monthly repayment schedule calculated before submission.
            </p>

            <form onSubmit={handleSubmitLoan} className="mt-6 space-y-5">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label htmlFor="loan-principal" className="block text-xs font-medium text-stone-700">
                    Requested Principal (ZAR): <span className="font-mono font-semibold">{formatZar(principalZar)}</span>
                  </label>
                  <input
                    id="loan-principal"
                    type="range"
                    min={500}
                    max={25000}
                    step={500}
                    value={principalZar}
                    onChange={(e) => setPrincipalZar(Number(e.target.value))}
                    className="mt-2 w-full accent-[#14532D]"
                  />
                  <div className="flex justify-between text-[11px] text-stone-400 font-mono mt-1">
                    <span>R 500</span>
                    <span>R 25,000</span>
                  </div>
                </div>

                <div>
                  <label htmlFor="loan-term" className="block text-xs font-medium text-stone-700">
                    Repayment Term (Months): <span className="font-mono font-semibold">{termMonths} mo</span>
                  </label>
                  <input
                    id="loan-term"
                    type="range"
                    min={1}
                    max={12}
                    step={1}
                    value={termMonths}
                    onChange={(e) => setTermMonths(Number(e.target.value))}
                    className="mt-2 w-full accent-[#14532D]"
                  />
                  <div className="flex justify-between text-[11px] text-stone-400 font-mono mt-1">
                    <span>1 mo</span>
                    <span>12 mo</span>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label htmlFor="loan-applicant-name" className="block text-xs font-medium text-stone-700">
                    Applicant Full Name
                  </label>
                  <input
                    id="loan-applicant-name"
                    type="text"
                    value={applicantName}
                    onChange={(e) => setApplicantName(e.target.value)}
                    placeholder="e.g. Boitumelo Sekoto"
                    className="mt-1 w-full rounded-lg border border-stone-300 px-3 py-2 text-sm focus:border-[#14532D] focus:outline-none"
                  />
                </div>
                <div>
                  <label htmlFor="loan-applicant-phone" className="block text-xs font-medium text-stone-700">
                    Mobile Phone
                  </label>
                  <input
                    id="loan-applicant-phone"
                    type="tel"
                    value={applicantPhone}
                    onChange={(e) => setApplicantPhone(e.target.value)}
                    placeholder="+27 83 000 0000"
                    className="mt-1 w-full rounded-lg border border-stone-300 px-3 py-2 text-sm focus:border-[#14532D] focus:outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label htmlFor="loan-id-last4" className="block text-xs font-medium text-stone-700">
                    SA ID (Last 4 Digits)
                  </label>
                  <input
                    id="loan-id-last4"
                    type="text"
                    maxLength={4}
                    value={nationalIdLast4}
                    onChange={(e) => setNationalIdLast4(e.target.value.replace(/\D/g, ''))}
                    placeholder="4821"
                    className="mt-1 w-full rounded-lg border border-stone-300 px-3 py-2 text-sm font-mono tabular-nums focus:border-[#14532D] focus:outline-none"
                  />
                </div>
                <div>
                  <label htmlFor="loan-income" className="block text-xs font-medium text-stone-700">
                    Monthly Income (ZAR)
                  </label>
                  <input
                    id="loan-income"
                    type="number"
                    min={1500}
                    step={500}
                    value={monthlyIncomeZar}
                    onChange={(e) => setMonthlyIncomeZar(Number(e.target.value) || 0)}
                    className="mt-1 w-full rounded-lg border border-stone-300 px-3 py-2 text-sm font-mono tabular-nums focus:border-[#14532D] focus:outline-none"
                  />
                </div>
                <div>
                  <label htmlFor="loan-purpose" className="block text-xs font-medium text-stone-700">
                    Loan Purpose
                  </label>
                  <select
                    id="loan-purpose"
                    value={loanPurpose}
                    onChange={(e) => setLoanPurpose(e.target.value as LoanPurpose)}
                    className="mt-1 w-full rounded-lg border border-stone-300 px-3 py-2 text-sm bg-white focus:border-[#14532D] focus:outline-none"
                  >
                    <option value="Working Capital">Working Capital</option>
                    <option value="Agricultural Inputs">Agricultural Inputs</option>
                    <option value="Transport & Logistics">Transport &amp; Logistics</option>
                    <option value="Personal Emergency">Personal Emergency</option>
                  </select>
                </div>
              </div>

              {loanMessage && (
                <div
                  role="status"
                  className={`rounded-lg border p-3 text-xs ${
                    loanMessage.type === 'ok'
                      ? 'border-emerald-200 bg-emerald-50 text-emerald-900'
                      : 'border-red-200 bg-red-50 text-red-900'
                  }`}
                >
                  {loanMessage.text}
                </div>
              )}

              <button
                type="submit"
                disabled={loanSubmitting}
                className="px-6 py-3 bg-[#14532D] text-white text-sm font-semibold rounded-lg hover:bg-[#114224] disabled:opacity-60 transition-colors cursor-pointer"
              >
                {loanSubmitting ? 'Submitting Application...' : 'Submit Microloan Application'}
              </button>
            </form>
          </div>

          <aside className="lg:col-span-5 bg-white border border-stone-200 rounded-xl p-6 sm:p-8">
            <p className="text-xs font-medium text-stone-500">Estimated Monthly Installment</p>
            <p className="mt-2 font-display text-3xl font-bold text-stone-900 font-mono tabular-nums">
              {formatZar(loanCalc.monthlyInstallmentZar)}
            </p>
            <p className="mt-1 text-xs text-stone-500 tabular-nums">
              for {loanCalc.termMonths} months at {loanCalc.monthlyRatePct}% monthly flat rate
            </p>

            <dl className="mt-6 space-y-2.5 pt-5 border-t border-stone-200 text-sm">
              <div className="flex justify-between text-stone-600">
                <dt>Principal Amount</dt>
                <dd className="font-mono tabular-nums">{formatZar(loanCalc.principalZar)}</dd>
              </div>
              <div className="flex justify-between text-stone-600">
                <dt>Initiation Fee</dt>
                <dd className="font-mono tabular-nums">{formatZar(loanCalc.initiationFeeZar)}</dd>
              </div>
              <div className="flex justify-between text-stone-600">
                <dt>Total Interest</dt>
                <dd className="font-mono tabular-nums">{formatZar(loanCalc.totalInterestZar)}</dd>
              </div>
              <div className="flex justify-between pt-2 border-t border-stone-200 font-bold text-stone-900">
                <dt>Total Repayable</dt>
                <dd className="font-mono tabular-nums">{formatZar(loanCalc.totalRepayableZar)}</dd>
              </div>
            </dl>

            <div className="mt-6 pt-5 border-t border-stone-200">
              <div className="flex items-center justify-between text-xs">
                <span className="text-stone-600">Affordability Ratio (Installment / Income)</span>
                <span
                  className={`font-mono font-semibold tabular-nums ${
                    loanCalc.recommendedEligible ? 'text-emerald-700' : 'text-amber-700'
                  }`}
                >
                  {loanCalc.debtToIncomePct}%
                </span>
              </div>
              <p className="mt-2 text-xs text-stone-500 flex items-center gap-1.5">
                <CheckCircle2
                  className={`h-4 w-4 shrink-0 ${
                    loanCalc.recommendedEligible ? 'text-emerald-700' : 'text-amber-600'
                  }`}
                />
                {loanCalc.recommendedEligible
                  ? 'Within 40% affordability guideline for standard review.'
                  : 'Exceeds 40% monthly income threshold — adjust amount or extend term.'}
              </p>
            </div>
          </aside>
        </section>
      )}

      {/* TAB 4: MY REQUESTS TRACKER */}
      {activeTab === 'requests' && (
        <section className="mt-8 space-y-8">
          <div className="bg-white border border-stone-200 rounded-xl overflow-hidden">
            <div className="px-6 py-4 border-b border-stone-200 flex items-center justify-between">
              <h2 className="font-display text-base font-bold text-stone-900">
                Lesobeng Farm Orders ({state.farmOrders.length})
              </h2>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left text-sm">
                <thead className="bg-stone-50 text-xs text-stone-500 border-b border-stone-200">
                  <tr>
                    <th className="px-6 py-3 font-medium">Order ID</th>
                    <th className="px-6 py-3 font-medium">Client</th>
                    <th className="px-6 py-3 font-medium">Location</th>
                    <th className="px-6 py-3 font-medium">Items</th>
                    <th className="px-6 py-3 font-medium text-right">Total</th>
                    <th className="px-6 py-3 font-medium">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-stone-100">
                  {state.farmOrders.map((order) => (
                    <tr key={order.id} className="hover:bg-stone-50">
                      <td className="px-6 py-3 font-mono text-xs text-stone-700">{order.id}</td>
                      <td className="px-6 py-3 font-medium text-stone-900">{order.clientName}</td>
                      <td className="px-6 py-3 text-stone-600">{order.deliveryLocation}</td>
                      <td className="px-6 py-3 text-stone-600">
                        {order.items.map((i) => `${i.quantity}× ${i.itemName}`).join(', ')}
                      </td>
                      <td className="px-6 py-3 text-right font-mono tabular-nums text-stone-900">
                        {formatZar(order.totalZar)}
                      </td>
                      <td className="px-6 py-3 text-xs font-semibold text-stone-800">{order.status}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          <div className="bg-white border border-stone-200 rounded-xl overflow-hidden">
            <div className="px-6 py-4 border-b border-stone-200">
              <h2 className="font-display text-base font-bold text-stone-900">
                E-Hailing Ride Requests ({state.rides.length})
              </h2>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left text-sm">
                <thead className="bg-stone-50 text-xs text-stone-500 border-b border-stone-200">
                  <tr>
                    <th className="px-6 py-3 font-medium">Ride ID</th>
                    <th className="px-6 py-3 font-medium">Passenger</th>
                    <th className="px-6 py-3 font-medium">Route</th>
                    <th className="px-6 py-3 font-medium">Driver</th>
                    <th className="px-6 py-3 font-medium text-right">Fare</th>
                    <th className="px-6 py-3 font-medium">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-stone-100">
                  {state.rides.map((ride) => (
                    <tr key={ride.id} className="hover:bg-stone-50">
                      <td className="px-6 py-3 font-mono text-xs text-stone-700">{ride.id}</td>
                      <td className="px-6 py-3 font-medium text-stone-900">{ride.passengerName}</td>
                      <td className="px-6 py-3 text-stone-600">
                        {ride.pickupLocation} → {ride.dropoffLocation} ({ride.distanceKm} km)
                      </td>
                      <td className="px-6 py-3 text-stone-600">{ride.assignedDriverName || 'Awaiting dispatch'}</td>
                      <td className="px-6 py-3 text-right font-mono tabular-nums text-stone-900">
                        {formatZar(ride.estimatedFareZar)}
                      </td>
                      <td className="px-6 py-3 text-xs font-semibold text-stone-800">{ride.status}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          <div className="bg-white border border-stone-200 rounded-xl overflow-hidden">
            <div className="px-6 py-4 border-b border-stone-200">
              <h2 className="font-display text-base font-bold text-stone-900">
                Microloan Applications ({state.loans.length})
              </h2>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left text-sm">
                <thead className="bg-stone-50 text-xs text-stone-500 border-b border-stone-200">
                  <tr>
                    <th className="px-6 py-3 font-medium">Loan ID</th>
                    <th className="px-6 py-3 font-medium">Applicant</th>
                    <th className="px-6 py-3 font-medium">Purpose</th>
                    <th className="px-6 py-3 font-medium text-right">Principal</th>
                    <th className="px-6 py-3 font-medium text-right">Monthly</th>
                    <th className="px-6 py-3 font-medium">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-stone-100">
                  {state.loans.map((loan) => (
                    <tr key={loan.id} className="hover:bg-stone-50">
                      <td className="px-6 py-3 font-mono text-xs text-stone-700">{loan.id}</td>
                      <td className="px-6 py-3 font-medium text-stone-900">{loan.applicantName}</td>
                      <td className="px-6 py-3 text-stone-600">{loan.purpose}</td>
                      <td className="px-6 py-3 text-right font-mono tabular-nums text-stone-900">
                        {formatZar(loan.principalZar)}
                      </td>
                      <td className="px-6 py-3 text-right font-mono tabular-nums text-stone-700">
                        {formatZar(loan.monthlyInstallmentZar)}
                      </td>
                      <td className="px-6 py-3 text-xs font-semibold text-stone-800">{loan.status}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </section>
      )}
    </main>
  );
}
