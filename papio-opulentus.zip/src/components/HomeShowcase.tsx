import { ArrowRight, Landmark, ShieldCheck } from 'lucide-react';
import { useState } from 'react';
import heroFarmImg from '../assets/images/hero_lesobeng_farm_1794599804888.jpg';
import farmLivestockImg from '../assets/images/division_farm_livestock_1794599805543.jpg';
import ehailingFleetImg from '../assets/images/division_ehailing_fleet_1794599805912.jpg';
import ownerPortraitImg from '../assets/images/owner_portrait_trevor_1794599806953.jpg';
import type { AppStatePayload } from '../types/domain';
import { calculateMicroloan, formatZar } from '../utils/businessLogic';
import type { ActiveWorkspace } from './Navbar';

interface HomeShowcaseProps {
  state: AppStatePayload;
  onNavigateWorkspace: (workspace: ActiveWorkspace, sectionOrTab?: string) => void;
}

export function HomeShowcase({ state, onNavigateWorkspace }: HomeShowcaseProps) {
  const [imgErrors, setImgErrors] = useState<Record<string, boolean>>({});

  const markImgError = (key: string) => {
    setImgErrors((prev) => ({ ...prev, [key]: true }));
  };

  const cropCount = state.farmItems.filter((i) => i.category === 'crops').length;
  const livestockCount = state.farmItems
    .filter((i) => i.category === 'livestock')
    .reduce((acc, item) => acc + item.quantityAvailable, 0);
  const activeDrivers = state.drivers.filter((d) => d.available).length;
  const loanBookTotal = state.loans
    .filter((l) => l.status === 'Approved' || l.status === 'Disbursed')
    .reduce((sum, l) => sum + l.principalZar, 0);
  const sampleLoan = calculateMicroloan(5000, 6, 3.5, 12000);

  return (
    <main id="top" className="bg-[#FAFAF9]">
      {/* 1. Hero Section */}
      <section className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 pt-10 pb-14 lg:pt-16 lg:pb-20">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-12 items-stretch">
          <div className="lg:col-span-6 flex flex-col justify-between">
            <div>
              <p className="text-xs sm:text-sm font-medium text-stone-500 mb-4">
                Moruleng Village, North West Province · Founded by {state.company.owner}
              </p>
              <h1 className="font-display text-[clamp(2.25rem,4vw,3.5rem)] font-bold tracking-tight leading-[1.08] text-stone-900">
                Commercial agriculture, regional mobility, and micro-credit from Moruleng.
              </h1>
              <p className="mt-5 text-base sm:text-lg text-stone-600 leading-relaxed max-w-xl">
                Papio Opulentus operates three integrated local businesses: crops and livestock raised at Lesobeng Farm, point-to-point E-Hailing across the Pilanesberg corridor, and transparent Microlending for households and enterprises.
              </p>
            </div>

            <div className="mt-8 flex flex-wrap items-center gap-4">
              <button
                type="button"
                onClick={() => onNavigateWorkspace('portal', 'farm')}
                className="inline-flex items-center gap-2 px-6 py-3 bg-[#14532D] text-white text-sm font-semibold rounded-lg hover:bg-[#114224] transition-colors duration-150 whitespace-nowrap shrink-0 cursor-pointer"
              >
                Open Client Portal
                <ArrowRight className="h-4 w-4" />
              </button>
              <button
                type="button"
                onClick={() => onNavigateWorkspace('dashboard', 'overview')}
                className="inline-flex items-center gap-2 px-5 py-3 border border-stone-300 bg-white text-stone-800 text-sm font-semibold rounded-lg hover:border-stone-400 hover:bg-stone-50 transition-colors duration-150 whitespace-nowrap shrink-0 cursor-pointer"
              >
                Manage Divisions
              </button>
            </div>
          </div>

          <div className="lg:col-span-6">
            <div className="relative h-72 sm:h-96 lg:h-full min-h-[340px] w-full overflow-hidden rounded-xl border border-stone-200 bg-stone-200">
              {!imgErrors.hero ? (
                <img
                  src={heroFarmImg}
                  alt="Lesobeng Farm in Moruleng Village showing irrigated crop rows and grazing Bonsmara cattle"
                  referrerPolicy="no-referrer"
                  onError={() => markImgError('hero')}
                  className="h-full w-full object-cover"
                />
              ) : (
                <div className="h-full w-full flex flex-col items-center justify-center bg-gradient-to-br from-stone-200 to-stone-300 p-8 text-center">
                  <p className="font-display text-lg font-semibold text-stone-800">Lesobeng Farm</p>
                  <p className="text-sm text-stone-600 mt-1">Moruleng Village · Crops &amp; Livestock</p>
                </div>
              )}
              <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/80 via-black/35 to-transparent p-6">
                <p className="text-xs font-medium text-stone-200">
                  Lesobeng Farm · Moruleng Village
                </p>
                <p className="mt-1 text-sm font-semibold text-white">
                  Mixed dryland maize, irrigated greens, and Bonsmara beef cattle
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Full-width 4-column operational strip below the hero split */}
        <div className="mt-12 grid grid-cols-2 lg:grid-cols-4 border-y border-stone-200 bg-white">
          <div className="p-6 border-r border-b lg:border-b-0 border-stone-200">
            <p className="text-xs font-medium text-stone-500">Lesobeng Crop Lines</p>
            <p className="mt-2 font-display text-2xl font-bold text-stone-900 tabular-nums">
              {cropCount} Active Lots
            </p>
            <p className="mt-1 text-xs text-stone-500">Maize, sorghum, spinach &amp; squash</p>
          </div>
          <div className="p-6 lg:border-r border-b lg:border-b-0 border-stone-200">
            <p className="text-xs font-medium text-stone-500">Livestock Headcount</p>
            <p className="mt-2 font-display text-2xl font-bold text-stone-900 tabular-nums">
              {livestockCount} Head &amp; Crates
            </p>
            <p className="mt-1 text-xs text-stone-500">Bonsmara cattle, Boer goats &amp; layers</p>
          </div>
          <div className="p-6 border-r border-stone-200">
            <p className="text-xs font-medium text-stone-500">E-Hailing Fleet</p>
            <p className="mt-2 font-display text-2xl font-bold text-stone-900 tabular-nums">
              {activeDrivers} Drivers Ready
            </p>
            <p className="mt-1 text-xs text-stone-500">Moruleng · Sun City · Rustenburg</p>
          </div>
          <div className="p-6">
            <p className="text-xs font-medium text-stone-500">Active Loan Book</p>
            <p className="mt-2 font-display text-2xl font-bold text-stone-900 tabular-nums">
              {formatZar(loanBookTotal)}
            </p>
            <p className="mt-1 text-xs text-stone-500">3.5% monthly flat interest</p>
          </div>
        </div>
      </section>

      {/* 2. Three Operating Divisions (Asymmetric Numbered Editorial Showcase) */}
      <section className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-12 lg:py-16 border-t border-stone-200">
        <div className="max-w-2xl mb-12">
          <p className="text-xs font-medium text-stone-500">Operating Divisions</p>
          <h2 className="mt-2 font-display text-2xl sm:text-3xl font-bold tracking-tight text-stone-900">
            Three divisions serving Moruleng Village and the wider Bojanala region.
          </h2>
        </div>

        <div className="space-y-12">
          {/* Division 01: Lesobeng Farm */}
          <article
            id="division-farm"
            className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch bg-white border border-stone-200 rounded-xl overflow-hidden"
          >
            <div className="lg:col-span-7 min-h-[260px] bg-stone-100">
              {!imgErrors.farm ? (
                <img
                  src={farmLivestockImg}
                  alt="Lesobeng Farm Bonsmara cattle and fresh harvested maize and spinach crates"
                  referrerPolicy="no-referrer"
                  onError={() => markImgError('farm')}
                  className="h-full w-full object-cover"
                />
              ) : (
                <div className="h-full w-full flex items-center justify-center p-8 text-stone-600">
                  Lesobeng Farm · Crops &amp; Livestock
                </div>
              )}
            </div>
            <div className="lg:col-span-5 p-6 sm:p-8 flex flex-col justify-between">
              <div>
                <p className="text-xs font-medium text-stone-500">
                  01. Agriculture · Moruleng Village
                </p>
                <h3 className="mt-2 font-display text-2xl font-bold text-stone-900">
                  Lesobeng Farm — Crops &amp; Livestock
                </h3>
                <p className="mt-3 text-sm sm:text-base text-stone-600 leading-relaxed">
                  Direct-from-farm seasonal harvests and registered breeding stock. We cultivate white milling maize, red sorghum, and drip-irrigated greens alongside pasture-raised Bonsmara beef cattle, Boer goats, and free-range layer pullets.
                </p>

                <dl className="mt-6 grid grid-cols-2 gap-4 pt-5 border-t border-stone-200 text-sm">
                  <div>
                    <dt className="text-xs text-stone-500">Primary Crops</dt>
                    <dd className="mt-1 font-semibold text-stone-900">Maize, Sorghum, Morogo</dd>
                  </div>
                  <div>
                    <dt className="text-xs text-stone-500">Livestock Breeds</dt>
                    <dd className="mt-1 font-semibold text-stone-900">Bonsmara &amp; Boer Goat</dd>
                  </div>
                </dl>
              </div>

              <div className="mt-8">
                <button
                  type="button"
                  onClick={() => onNavigateWorkspace('portal', 'farm')}
                  className="inline-flex items-center gap-2 px-5 py-2.5 bg-[#14532D] text-white text-sm font-semibold rounded-lg hover:bg-[#114224] transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                >
                  Order Produce or Livestock
                  <ArrowRight className="h-4 w-4" />
                </button>
              </div>
            </div>
          </article>

          {/* Division 02 & 03 Asymmetric Split */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
            {/* Division 02: E-Hailing */}
            <article
              id="division-ehailing"
              className="lg:col-span-7 bg-white border border-stone-200 rounded-xl overflow-hidden flex flex-col"
            >
              <div className="h-64 sm:h-72 bg-stone-100">
                {!imgErrors.ehailing ? (
                  <img
                    src={ehailingFleetImg}
                    alt="Papio Opulentus executive sedan waiting at regional transit hub"
                    referrerPolicy="no-referrer"
                    onError={() => markImgError('ehailing')}
                    className="h-full w-full object-cover"
                  />
                ) : (
                  <div className="h-full w-full flex items-center justify-center p-8 text-stone-600">
                    Papio E-Hailing Fleet
                  </div>
                )}
              </div>
              <div className="p-6 sm:p-8 flex-1 flex flex-col justify-between">
                <div>
                  <p className="text-xs font-medium text-stone-500">
                    02. Regional Mobility · North West Corridor
                  </p>
                  <h3 className="mt-2 font-display text-2xl font-bold text-stone-900">
                    Papio E-Hailing &amp; Dispatch
                  </h3>
                  <p className="mt-3 text-sm sm:text-base text-stone-600 leading-relaxed">
                    On-demand passenger rides and light farm-freight transport linking Moruleng Village, Mogwase, Sun City Resort, Pilanesberg Airport, and Rustenburg CBD with upfront ZAR fare calculation.
                  </p>
                </div>

                <div className="mt-6 pt-5 border-t border-stone-200 flex flex-wrap items-center justify-between gap-4">
                  <div className="text-xs text-stone-500 tabular-nums">
                    From <span className="font-semibold text-stone-900">R 35.00</span> base · Sedan, SUV &amp; Utility
                  </div>
                  <button
                    type="button"
                    onClick={() => onNavigateWorkspace('portal', 'ehailing')}
                    className="inline-flex items-center gap-2 px-5 py-2.5 bg-stone-900 text-white text-sm font-semibold rounded-lg hover:bg-[#14532D] transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                  >
                    Estimate &amp; Book Ride
                    <ArrowRight className="h-4 w-4" />
                  </button>
                </div>
              </div>
            </article>

            {/* Division 03: Microlending */}
            <article
              id="division-microlending"
              className="lg:col-span-5 bg-white border border-stone-200 rounded-xl overflow-hidden flex flex-col"
            >
              {/* Zero-Broken-Image styled architectural financial visual */}
              <div className="h-64 sm:h-72 bg-[#111827] text-white p-6 sm:p-8 flex flex-col justify-between">
                <div className="flex items-center justify-between text-xs text-stone-300">
                  <span>Transparent Micro-Credit Schedule</span>
                  <Landmark className="h-4 w-4 text-amber-400" />
                </div>
                <div>
                  <p className="text-xs text-stone-400">Sample 6-Month Facility</p>
                  <p className="mt-1 font-display text-3xl font-bold tracking-tight tabular-nums">
                    {formatZar(sampleLoan.principalZar)}
                  </p>
                  <div className="mt-4 grid grid-cols-2 gap-4 pt-4 border-t border-white/15 text-xs">
                    <div>
                      <span className="text-stone-400 block">Monthly Installment</span>
                      <span className="mt-0.5 block font-mono font-semibold text-white tabular-nums">
                        {formatZar(sampleLoan.monthlyInstallmentZar)}
                      </span>
                    </div>
                    <div>
                      <span className="text-stone-400 block">Monthly Interest</span>
                      <span className="mt-0.5 block font-mono font-semibold text-white tabular-nums">
                        3.5% Flat
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              <div className="p-6 sm:p-8 flex-1 flex flex-col justify-between">
                <div>
                  <p className="text-xs font-medium text-stone-500">
                    03. Financial Services · Households &amp; SMEs
                  </p>
                  <h3 className="mt-2 font-display text-2xl font-bold text-stone-900">
                    Papio Microlending
                  </h3>
                  <p className="mt-3 text-sm sm:text-base text-stone-600 leading-relaxed">
                    Structured short-term credit from R 500 to R 50,000 for working capital, agricultural inputs, and urgent household obligations—with upfront affordability checks and zero hidden fees.
                  </p>
                </div>

                <div className="mt-6 pt-5 border-t border-stone-200 flex items-center justify-between gap-4">
                  <span className="text-xs text-stone-500">1 to 24 month terms</span>
                  <button
                    type="button"
                    onClick={() => onNavigateWorkspace('portal', 'microlending')}
                    className="inline-flex items-center gap-2 px-5 py-2.5 bg-stone-900 text-white text-sm font-semibold rounded-lg hover:bg-[#14532D] transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                  >
                    Calculate &amp; Apply
                    <ArrowRight className="h-4 w-4" />
                  </button>
                </div>
              </div>
            </article>
          </div>
        </div>
      </section>

      {/* 3. Leadership & Domain Verification Assurance */}
      <section className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-14 border-t border-stone-200">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center bg-white border border-stone-200 rounded-xl p-6 sm:p-10">
          <div className="lg:col-span-3 flex justify-center lg:justify-start">
            <div className="h-44 w-44 overflow-hidden rounded-xl border border-stone-200 bg-stone-100">
              {!imgErrors.owner ? (
                <img
                  src={ownerPortraitImg}
                  alt="Mabuya Otshepeng Trevor, Owner and Managing Director of Papio Opulentus"
                  referrerPolicy="no-referrer"
                  onError={() => markImgError('owner')}
                  className="h-full w-full object-cover"
                />
              ) : (
                <div className="h-full w-full flex items-center justify-center text-sm font-semibold text-stone-700">
                  M. O. Trevor
                </div>
              )}
            </div>
          </div>

          <div className="lg:col-span-6">
            <p className="text-xs font-medium text-stone-500">Executive Leadership</p>
            <h2 className="mt-1 font-display text-2xl font-bold text-stone-900">
              {state.company.owner}
            </h2>
            <p className="mt-1 text-sm font-medium text-[#14532D]">
              Founder &amp; Managing Director, Papio Opulentus
            </p>
            <p className="mt-4 text-sm sm:text-base text-stone-600 leading-relaxed">
              Operating out of Moruleng Village, {state.company.owner} oversees Lesobeng Farm production, regional E-Hailing dispatch, and responsible microloan underwriting from a single unified command dashboard—including external domain and Google Play Console app verification.
            </p>
          </div>

          <div className="lg:col-span-3 flex flex-col gap-3 lg:items-end">
            <button
              type="button"
              onClick={() => onNavigateWorkspace('dashboard', 'verification')}
              className="inline-flex items-center justify-center gap-2 px-5 py-3 border border-stone-300 bg-stone-50 text-stone-900 text-sm font-semibold rounded-lg hover:bg-stone-100 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              <ShieldCheck className="h-4 w-4 text-[#14532D]" />
              Domain &amp; Play Verification
            </button>
            <p className="text-xs text-stone-500 lg:text-right">
              Live endpoints for Play Console &amp; Search Console
            </p>
          </div>
        </div>
      </section>

      {/* 4. Quiet Footer */}
      <footer className="border-t border-stone-200 bg-white">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-8 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 text-xs text-stone-500">
          <div>
            <span className="font-display font-semibold text-stone-900">Papio Opulentus</span>
            <span className="mx-2" aria-hidden="true">·</span>
            <span>Lesobeng Farm, Moruleng Village, North West</span>
            <span className="mx-2" aria-hidden="true">·</span>
            <span>Owner: {state.company.owner}</span>
          </div>
          <div className="flex flex-wrap items-center gap-4">
            <a
              href="/.well-known/assetlinks.json"
              target="_blank"
              rel="noreferrer"
              className="hover:text-stone-900 underline underline-offset-4"
            >
              Digital Asset Links
            </a>
            <button
              type="button"
              onClick={() => onNavigateWorkspace('portal', 'farm')}
              className="hover:text-stone-900 underline underline-offset-4 cursor-pointer"
            >
              Client Portal
            </button>
            <button
              type="button"
              onClick={() => onNavigateWorkspace('dashboard', 'overview')}
              className="hover:text-stone-900 underline underline-offset-4 cursor-pointer"
            >
              Owner Dashboard
            </button>
          </div>
        </div>
      </footer>
    </main>
  );
}
