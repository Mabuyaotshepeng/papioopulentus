import {
  Car,
  Landmark,
  LayoutDashboard,
  Plus,
  ShieldCheck,
  Sprout,
  Trash2,
} from 'lucide-react';
import { useState } from 'react';
import type {
  AppStatePayload,
  FarmCategory,
  FarmHealthStatus,
  FarmOrderStatus,
  LoanStatus,
  RideStatus,
  VehicleClass,
} from '../types/domain';
import { formatZar } from '../utils/businessLogic';
import { VerificationPanel } from './VerificationPanel';

export type DashboardSection =
  | 'overview'
  | 'farm'
  | 'ehailing'
  | 'microlending'
  | 'verification';

interface OwnerDashboardProps {
  state: AppStatePayload;
  activeSection: DashboardSection;
  onChangeSection: (section: DashboardSection) => void;
  onRefreshState: () => Promise<void>;
  onSwitchToPortal: () => void;
}

const SECTION_LABELS: Record<DashboardSection, string> = {
  overview: 'Executive Overview',
  farm: 'Lesobeng Farm (Crops & Livestock)',
  ehailing: 'E-Hailing Fleet & Dispatch',
  microlending: 'Microlending Underwriting Desk',
  verification: 'Website & Play Console Verification',
};

export function OwnerDashboard({
  state,
  activeSection,
  onChangeSection,
  onRefreshState,
  onSwitchToPortal,
}: OwnerDashboardProps) {
  // Farm Item Creation Form
  const [farmFilter, setFarmFilter] = useState<'all' | FarmCategory>('all');
  const [newItemName, setNewItemName] = useState('');
  const [newItemCat, setNewItemCat] = useState<FarmCategory>('crops');
  const [newItemVariety, setNewItemVariety] = useState('');
  const [newItemUnit, setNewItemUnit] = useState('50kg Bag');
  const [newItemQty, setNewItemQty] = useState(25);
  const [newItemPrice, setNewItemPrice] = useState(400);
  const [newItemSection, setNewItemSection] = useState('Lesobeng Block C');
  const [farmFeedback, setFarmFeedback] = useState<string | null>(null);

  // Driver Creation Form
  const [drvName, setDrvName] = useState('');
  const [drvPhone, setDrvPhone] = useState('');
  const [drvVehicle, setDrvVehicle] = useState('');
  const [drvClass, setDrvClass] = useState<VehicleClass>('Standard Sedan');
  const [drvPlate, setDrvPlate] = useState('');
  const [drvHub, setDrvHub] = useState('Moruleng Central Hub');
  const [driverFeedback, setDriverFeedback] = useState<string | null>(null);

  const [busyId, setBusyId] = useState<string | null>(null);

  // Aggregate KPIs
  const pendingOrdersCount = state.farmOrders.filter((o) => o.status === 'Pending').length;
  const farmOrderRevenue = state.farmOrders
    .filter((o) => o.status !== 'Cancelled')
    .reduce((sum, o) => sum + o.totalZar, 0);
  const unassignedRidesCount = state.rides.filter((r) => r.status === 'Requested').length;
  const pendingLoansCount = state.loans.filter((l) => l.status === 'Pending Review').length;
  const activeLoanBook = state.loans
    .filter((l) => l.status === 'Approved' || l.status === 'Disbursed')
    .reduce((sum, l) => sum + l.principalZar, 0);

  const filteredFarmItems =
    farmFilter === 'all'
      ? state.farmItems
      : state.farmItems.filter((item) => item.category === farmFilter);

  const handleAddFarmItem = async (e: React.FormEvent) => {
    e.preventDefault();
    setFarmFeedback(null);
    if (!newItemName.trim()) {
      setFarmFeedback('Enter a crop or livestock name.');
      return;
    }
    const res = await fetch('/api/farm/items', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        name: newItemName,
        category: newItemCat,
        varietyOrBreed: newItemVariety || 'Lesobeng Standard',
        unit: newItemUnit,
        quantityAvailable: newItemQty,
        unitPriceZar: newItemPrice,
        locationSection: newItemSection,
      }),
    });
    if (res.ok) {
      setNewItemName('');
      setNewItemVariety('');
      await onRefreshState();
      setFarmFeedback('Farm inventory item added.');
    } else {
      const err = await res.json();
      setFarmFeedback(err.error || 'Could not add item.');
    }
  };

  const handleAdjustStock = async (id: string, nextQty: number) => {
    setBusyId(id);
    await fetch(`/api/farm/items/${id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ quantityAvailable: Math.max(0, nextQty) }),
    });
    await onRefreshState();
    setBusyId(null);
  };

  const handleFarmStatus = async (id: string, status: FarmHealthStatus) => {
    setBusyId(id);
    await fetch(`/api/farm/items/${id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status }),
    });
    await onRefreshState();
    setBusyId(null);
  };

  const handleDeleteFarmItem = async (id: string) => {
    setBusyId(id);
    await fetch(`/api/farm/items/${id}`, { method: 'DELETE' });
    await onRefreshState();
    setBusyId(null);
  };

  const handleOrderStatus = async (id: string, status: FarmOrderStatus) => {
    setBusyId(id);
    await fetch(`/api/farm/orders/${id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status }),
    });
    await onRefreshState();
    setBusyId(null);
  };

  const handleAddDriver = async (e: React.FormEvent) => {
    e.preventDefault();
    setDriverFeedback(null);
    if (!drvName.trim() || !drvPhone.trim() || !drvVehicle.trim() || !drvPlate.trim()) {
      setDriverFeedback('Complete all driver and vehicle fields.');
      return;
    }
    const res = await fetch('/api/ehailing/drivers', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        fullName: drvName,
        phone: drvPhone,
        vehicleModel: drvVehicle,
        vehicleClass: drvClass,
        plateNumber: drvPlate,
        hubZone: drvHub,
      }),
    });
    if (res.ok) {
      setDrvName('');
      setDrvPhone('');
      setDrvVehicle('');
      setDrvPlate('');
      await onRefreshState();
      setDriverFeedback('Driver added to fleet.');
    }
  };

  const handleAssignRideDriver = async (rideId: string, driverId: string) => {
    setBusyId(rideId);
    await fetch(`/api/ehailing/rides/${rideId}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ assignedDriverId: driverId || null }),
    });
    await onRefreshState();
    setBusyId(null);
  };

  const handleRideStatus = async (rideId: string, status: RideStatus) => {
    setBusyId(rideId);
    await fetch(`/api/ehailing/rides/${rideId}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status }),
    });
    await onRefreshState();
    setBusyId(null);
  };

  const handleToggleDriver = async (driverId: string, available: boolean) => {
    setBusyId(driverId);
    await fetch(`/api/ehailing/drivers/${driverId}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ available }),
    });
    await onRefreshState();
    setBusyId(null);
  };

  const handleLoanStatus = async (loanId: string, status: LoanStatus) => {
    setBusyId(loanId);
    await fetch(`/api/microlending/loans/${loanId}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status }),
    });
    await onRefreshState();
    setBusyId(null);
  };

  const handleLoanRepayment = async (loanId: string, amount: number) => {
    setBusyId(loanId);
    await fetch(`/api/microlending/loans/${loanId}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ repaymentPaymentZar: amount }),
    });
    await onRefreshState();
    setBusyId(null);
  };

  const navItems: { id: DashboardSection; label: string; icon: typeof LayoutDashboard }[] = [
    { id: 'overview', label: 'Overview', icon: LayoutDashboard },
    { id: 'farm', label: 'Lesobeng Farm', icon: Sprout },
    { id: 'ehailing', label: 'E-Hailing', icon: Car },
    { id: 'microlending', label: 'Microlending', icon: Landmark },
    { id: 'verification', label: 'Website Verification', icon: ShieldCheck },
  ];

  return (
    <div className="min-h-[calc(100vh-4rem)] bg-[#FAFAF9] flex flex-col lg:flex-row">
      {/* Sidebar Navigation (240px on desktop) */}
      <aside className="lg:w-64 lg:shrink-0 border-b lg:border-b-0 lg:border-r border-stone-200 bg-white p-4 lg:p-6">
        <div className="mb-4 lg:mb-6 pb-4 border-b border-stone-200">
          <p className="text-xs font-medium text-stone-500">Executive Console</p>
          <p className="mt-0.5 font-display text-sm font-bold text-stone-900">
            {state.company.owner}
          </p>
          <p className="text-xs text-stone-500">Moruleng Village HQ</p>
        </div>

        <nav aria-label="Dashboard sections" className="flex lg:flex-col gap-1 overflow-x-auto pb-1 lg:pb-0">
          {navItems.map((item) => {
            const Icon = item.icon;
            const active = activeSection === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => onChangeSection(item.id)}
                className={`inline-flex items-center gap-2.5 px-3 py-2.5 rounded-lg text-xs sm:text-sm font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                  active
                    ? 'bg-[#14532D] text-white'
                    : 'text-stone-700 hover:bg-stone-100'
                }`}
              >
                <Icon className="h-4 w-4 shrink-0" />
                {item.label}
              </button>
            );
          })}
        </nav>
      </aside>

      {/* Main Workspace Viewport */}
      <main className="flex-1 min-w-0">
        {/* Contextual Breadcrumb Top Header */}
        <div className="border-b border-stone-200 bg-white px-4 sm:px-8 py-4 flex flex-wrap items-center justify-between gap-4">
          <div className="text-xs sm:text-sm text-stone-500">
            <span className="font-medium text-stone-900">Papio Opulentus</span>
            <span className="mx-2">/</span>
            <span>Owner Console</span>
            <span className="mx-2">/</span>
            <span className="font-semibold text-[#14532D]">{SECTION_LABELS[activeSection]}</span>
          </div>
          <button
            type="button"
            onClick={onSwitchToPortal}
            className="px-3.5 py-1.5 text-xs font-semibold border border-stone-300 rounded-lg text-stone-800 hover:bg-stone-50 whitespace-nowrap shrink-0 cursor-pointer"
          >
            Preview Client Portal
          </button>
        </div>

        <div className="p-4 sm:p-8 max-w-6xl">
          {/* SECTION 1: OVERVIEW */}
          {activeSection === 'overview' && (
            <div className="space-y-8">
              <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
                <div className="bg-white border border-stone-200 rounded-xl p-5">
                  <p className="text-xs text-stone-500">Lesobeng Farm Orders</p>
                  <p className="mt-2 font-display text-2xl font-bold text-stone-900 tabular-nums">
                    {formatZar(farmOrderRevenue)}
                  </p>
                  <p className="mt-1 text-xs text-stone-600 tabular-nums">
                    {pendingOrdersCount} pending fulfillment
                  </p>
                </div>

                <div className="bg-white border border-stone-200 rounded-xl p-5">
                  <p className="text-xs text-stone-500">E-Hailing Dispatch Queue</p>
                  <p className="mt-2 font-display text-2xl font-bold text-stone-900 tabular-nums">
                    {unassignedRidesCount} Unassigned
                  </p>
                  <p className="mt-1 text-xs text-stone-600 tabular-nums">
                    {state.drivers.filter((d) => d.available).length} of {state.drivers.length} drivers online
                  </p>
                </div>

                <div className="bg-white border border-stone-200 rounded-xl p-5">
                  <p className="text-xs text-stone-500">Microlending Active Principal</p>
                  <p className="mt-2 font-display text-2xl font-bold text-stone-900 tabular-nums">
                    {formatZar(activeLoanBook)}
                  </p>
                  <p className="mt-1 text-xs text-stone-600 tabular-nums">
                    {pendingLoansCount} {pendingLoansCount === 1 ? 'application' : 'applications'} awaiting review
                  </p>
                </div>

                <div className="bg-white border border-stone-200 rounded-xl p-5">
                  <p className="text-xs text-stone-500">External Verification</p>
                  <p className="mt-2 font-display text-2xl font-bold text-[#14532D] tabular-nums">
                    {state.verification.assetLinks.filter((a) => a.enabled).length}{' '}
                    {state.verification.assetLinks.filter((a) => a.enabled).length === 1 ? 'App Link' : 'App Links'}
                  </p>
                  <p className="mt-1 text-xs text-stone-600 tabular-nums">
                    {state.verification.htmlFiles.filter((f) => f.enabled).length} HTML ·{' '}
                    {state.verification.metaTags.filter((m) => m.enabled).length} Meta active
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <div className="bg-white border border-stone-200 rounded-xl p-6">
                  <div className="flex items-center justify-between gap-3 mb-4">
                    <h2 className="font-display text-base font-bold text-stone-900">
                      Recent Division Activity
                    </h2>
                    <button
                      type="button"
                      onClick={() => onChangeSection('microlending')}
                      className="text-xs font-semibold text-[#14532D] hover:underline cursor-pointer"
                    >
                      Open Underwriting Desk
                    </button>
                  </div>
                  <div className="divide-y divide-stone-100 text-sm">
                    {state.loans.slice(0, 3).map((loan) => (
                      <div key={loan.id} className="py-3 flex items-center justify-between gap-4">
                        <div>
                          <p className="font-medium text-stone-900">
                            {loan.applicantName} · {loan.purpose}
                          </p>
                          <p className="text-xs text-stone-500 font-mono">
                            {loan.id} · {loan.termMonths} months
                          </p>
                        </div>
                        <div className="text-right">
                          <p className="font-mono font-semibold text-stone-900 tabular-nums">
                            {formatZar(loan.principalZar)}
                          </p>
                          <p className="text-xs text-stone-600">{loan.status}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="bg-white border border-stone-200 rounded-xl p-6 flex flex-col justify-between">
                  <div>
                    <h2 className="font-display text-base font-bold text-stone-900">
                      Google Play Console &amp; Site Ownership
                    </h2>
                    <p className="mt-1 text-sm text-stone-600">
                      Verify your Papio Opulentus domain for Google Play Console App Integrity, Android App Links, and Google Search Console directly from this dashboard.
                    </p>
                    <dl className="mt-4 space-y-2 text-xs border-t border-stone-200 pt-4">
                      <div className="flex justify-between gap-3">
                        <dt className="text-stone-500">Asset Links Endpoint</dt>
                        <dd className="font-mono text-stone-900">/.well-known/assetlinks.json</dd>
                      </div>
                      <div className="flex justify-between gap-3">
                        <dt className="text-stone-500">Primary Android Package</dt>
                        <dd className="font-mono text-stone-900">
                          {state.verification.assetLinks[0]?.packageName || 'None configured'}
                        </dd>
                      </div>
                    </dl>
                  </div>
                  <div className="mt-6">
                    <button
                      type="button"
                      onClick={() => onChangeSection('verification')}
                      className="px-4 py-2.5 bg-stone-900 text-white text-xs font-semibold rounded-lg hover:bg-[#14532D] transition-colors cursor-pointer"
                    >
                      Manage External Verification
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* SECTION 2: LESOBENG FARM MANAGEMENT */}
          {activeSection === 'farm' && (
            <div className="space-y-8">
              {/* Inventory Table */}
              <div className="bg-white border border-stone-200 rounded-xl overflow-hidden">
                <div className="px-6 py-4 border-b border-stone-200 flex flex-wrap items-center justify-between gap-4">
                  <div>
                    <h2 className="font-display text-base font-bold text-stone-900">
                      Lesobeng Farm Crops &amp; Livestock Ledger
                    </h2>
                    <p className="text-xs text-stone-500">Moruleng Village · Adjust stock counts and health status</p>
                  </div>
                  <div className="inline-flex items-center gap-1 p-1 bg-stone-100 rounded-lg">
                    {(['all', 'crops', 'livestock'] as const).map((cat) => (
                      <button
                        key={cat}
                        type="button"
                        onClick={() => setFarmFilter(cat)}
                        className={`px-3 py-1 text-xs font-medium rounded-md capitalize cursor-pointer ${
                          farmFilter === cat
                            ? 'bg-white text-stone-900 shadow-sm'
                            : 'text-stone-600 hover:text-stone-900'
                        }`}
                      >
                        {cat}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="overflow-x-auto">
                  <table className="w-full text-left text-sm">
                    <thead className="bg-stone-50 text-xs text-stone-500 border-b border-stone-200">
                      <tr>
                        <th className="px-6 py-3 font-medium">Item / Variety</th>
                        <th className="px-6 py-3 font-medium">Category</th>
                        <th className="px-6 py-3 font-medium">Section</th>
                        <th className="px-6 py-3 font-medium text-right">Price</th>
                        <th className="px-6 py-3 font-medium text-right">Stock</th>
                        <th className="px-6 py-3 font-medium">Status</th>
                        <th className="px-6 py-3 font-medium text-right">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-stone-100">
                      {filteredFarmItems.map((item) => (
                        <tr key={item.id} className="hover:bg-stone-50">
                          <td className="px-6 py-3">
                            <p className="font-semibold text-stone-900">{item.name}</p>
                            <p className="text-xs text-stone-500">{item.varietyOrBreed}</p>
                          </td>
                          <td className="px-6 py-3 capitalize text-xs text-stone-700">{item.category}</td>
                          <td className="px-6 py-3 text-xs text-stone-600">{item.locationSection}</td>
                          <td className="px-6 py-3 text-right font-mono tabular-nums text-stone-900">
                            {formatZar(item.unitPriceZar)}
                          </td>
                          <td className="px-6 py-3 text-right font-mono tabular-nums">
                            {item.quantityAvailable} {item.unit}
                          </td>
                          <td className="px-6 py-3">
                            <select
                              aria-label={`Health status for ${item.name}`}
                              value={item.status}
                              disabled={busyId === item.id}
                              onChange={(e) => handleFarmStatus(item.id, e.target.value as FarmHealthStatus)}
                              className="rounded border border-stone-300 bg-white px-2 py-1 text-xs"
                            >
                              <option value="Healthy">Healthy</option>
                              <option value="Ready for Harvest">Ready for Harvest</option>
                              <option value="Low Stock">Low Stock</option>
                              <option value="Quarantine Review">Quarantine Review</option>
                            </select>
                          </td>
                          <td className="px-6 py-3 text-right">
                            <div className="inline-flex items-center gap-1.5">
                              <button
                                type="button"
                                aria-label={`Add 10 units to ${item.name}`}
                                disabled={busyId === item.id}
                                onClick={() => handleAdjustStock(item.id, item.quantityAvailable + 10)}
                                className="px-2 py-1 text-xs font-mono border border-stone-300 rounded hover:bg-stone-100 cursor-pointer"
                              >
                                +10
                              </button>
                              <button
                                type="button"
                                aria-label={`Delete ${item.name}`}
                                disabled={busyId === item.id}
                                onClick={() => handleDeleteFarmItem(item.id)}
                                className="p-1.5 text-stone-400 hover:text-red-600 cursor-pointer"
                              >
                                <Trash2 className="h-3.5 w-3.5" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Add Farm Item + Manage Client Orders */}
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
                <form
                  onSubmit={handleAddFarmItem}
                  className="lg:col-span-5 bg-white border border-stone-200 rounded-xl p-6 space-y-3"
                >
                  <h3 className="font-display text-base font-bold text-stone-900">
                    Add Crop or Livestock Lot
                  </h3>
                  <div>
                    <label htmlFor="new-farm-name" className="block text-xs text-stone-600">
                      Crop or Livestock Name
                    </label>
                    <input
                      id="new-farm-name"
                      type="text"
                      value={newItemName}
                      onChange={(e) => setNewItemName(e.target.value)}
                      placeholder="e.g. Nguni Breeding Bull"
                      className="mt-1 w-full rounded-lg border border-stone-300 px-3 py-2 text-xs focus:border-[#14532D] focus:outline-none"
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label htmlFor="new-farm-cat" className="block text-xs text-stone-600">
                        Category
                      </label>
                      <select
                        id="new-farm-cat"
                        value={newItemCat}
                        onChange={(e) => setNewItemCat(e.target.value as FarmCategory)}
                        className="mt-1 w-full rounded-lg border border-stone-300 px-2.5 py-2 text-xs bg-white"
                      >
                        <option value="crops">Crops</option>
                        <option value="livestock">Livestock</option>
                      </select>
                    </div>
                    <div>
                      <label htmlFor="new-farm-unit" className="block text-xs text-stone-600">
                        Unit
                      </label>
                      <input
                        id="new-farm-unit"
                        type="text"
                        value={newItemUnit}
                        onChange={(e) => setNewItemUnit(e.target.value)}
                        className="mt-1 w-full rounded-lg border border-stone-300 px-3 py-2 text-xs"
                      />
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label htmlFor="new-farm-qty" className="block text-xs text-stone-600">
                        Quantity Available
                      </label>
                      <input
                        id="new-farm-qty"
                        type="number"
                        min={0}
                        value={newItemQty}
                        onChange={(e) => setNewItemQty(Number(e.target.value))}
                        className="mt-1 w-full rounded-lg border border-stone-300 px-3 py-2 text-xs font-mono"
                      />
                    </div>
                    <div>
                      <label htmlFor="new-farm-price" className="block text-xs text-stone-600">
                        Unit Price (ZAR)
                      </label>
                      <input
                        id="new-farm-price"
                        type="number"
                        min={1}
                        value={newItemPrice}
                        onChange={(e) => setNewItemPrice(Number(e.target.value))}
                        className="mt-1 w-full rounded-lg border border-stone-300 px-3 py-2 text-xs font-mono"
                      />
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label htmlFor="new-farm-variety" className="block text-xs text-stone-600">
                        Variety / Breed
                      </label>
                      <input
                        id="new-farm-variety"
                        type="text"
                        value={newItemVariety}
                        onChange={(e) => setNewItemVariety(e.target.value)}
                        placeholder="e.g. Certified Seed"
                        className="mt-1 w-full rounded-lg border border-stone-300 px-3 py-2 text-xs"
                      />
                    </div>
                    <div>
                      <label htmlFor="new-farm-section" className="block text-xs text-stone-600">
                        Farm Camp / Plot
                      </label>
                      <input
                        id="new-farm-section"
                        type="text"
                        value={newItemSection}
                        onChange={(e) => setNewItemSection(e.target.value)}
                        className="mt-1 w-full rounded-lg border border-stone-300 px-3 py-2 text-xs"
                      />
                    </div>
                  </div>
                  {farmFeedback && <p className="text-xs text-[#14532D] font-medium">{farmFeedback}</p>}
                  <button
                    type="submit"
                    className="inline-flex items-center gap-1.5 px-4 py-2 bg-[#14532D] text-white text-xs font-semibold rounded-lg hover:bg-[#114224] cursor-pointer"
                  >
                    <Plus className="h-3.5 w-3.5" />
                    Add to Lesobeng Inventory
                  </button>
                </form>

                <div className="lg:col-span-7 bg-white border border-stone-200 rounded-xl overflow-hidden">
                  <div className="px-6 py-4 border-b border-stone-200">
                    <h3 className="font-display text-base font-bold text-stone-900">
                      Client Farm Orders ({state.farmOrders.length})
                    </h3>
                  </div>
                  <div className="divide-y divide-stone-100">
                    {state.farmOrders.map((order) => (
                      <div key={order.id} className="p-4 sm:px-6 flex flex-wrap items-center justify-between gap-4 text-sm">
                        <div>
                          <p className="font-semibold text-stone-900">
                            {order.id} · {order.clientName}
                          </p>
                          <p className="text-xs text-stone-500">
                            {order.deliveryLocation} · {order.items.map((i) => `${i.quantity}× ${i.itemName}`).join(', ')}
                          </p>
                        </div>
                        <div className="flex items-center gap-3">
                          <span className="font-mono font-semibold text-stone-900 tabular-nums">
                            {formatZar(order.totalZar)}
                          </span>
                          <select
                            aria-label={`Order status for ${order.id}`}
                            value={order.status}
                            disabled={busyId === order.id}
                            onChange={(e) => handleOrderStatus(order.id, e.target.value as FarmOrderStatus)}
                            className="rounded border border-stone-300 bg-white px-2.5 py-1 text-xs"
                          >
                            <option value="Pending">Pending</option>
                            <option value="Confirmed">Confirmed</option>
                            <option value="Dispatched">Dispatched</option>
                            <option value="Fulfilled">Fulfilled</option>
                            <option value="Cancelled">Cancelled</option>
                          </select>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* SECTION 3: E-HAILING DISPATCH & FLEET */}
          {activeSection === 'ehailing' && (
            <div className="space-y-8">
              <div className="bg-white border border-stone-200 rounded-xl overflow-hidden">
                <div className="px-6 py-4 border-b border-stone-200">
                  <h2 className="font-display text-base font-bold text-stone-900">
                    Live Ride Dispatch Board ({state.rides.length})
                  </h2>
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-sm">
                    <thead className="bg-stone-50 text-xs text-stone-500 border-b border-stone-200">
                      <tr>
                        <th className="px-6 py-3 font-medium">Ride</th>
                        <th className="px-6 py-3 font-medium">Passenger</th>
                        <th className="px-6 py-3 font-medium">Route</th>
                        <th className="px-6 py-3 font-medium text-right">Fare</th>
                        <th className="px-6 py-3 font-medium">Assign Driver</th>
                        <th className="px-6 py-3 font-medium">Status</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-stone-100">
                      {state.rides.map((ride) => (
                        <tr key={ride.id} className="hover:bg-stone-50">
                          <td className="px-6 py-3 font-mono text-xs text-stone-700">{ride.id}</td>
                          <td className="px-6 py-3">
                            <p className="font-medium text-stone-900">{ride.passengerName}</p>
                            <p className="text-xs text-stone-500">{ride.vehicleClass}</p>
                          </td>
                          <td className="px-6 py-3 text-xs text-stone-700">
                            {ride.pickupLocation} → {ride.dropoffLocation} ({ride.distanceKm} km)
                          </td>
                          <td className="px-6 py-3 text-right font-mono tabular-nums text-stone-900">
                            {formatZar(ride.estimatedFareZar)}
                          </td>
                          <td className="px-6 py-3">
                            <select
                              aria-label={`Assign driver for ${ride.id}`}
                              value={ride.assignedDriverId || ''}
                              disabled={busyId === ride.id}
                              onChange={(e) => handleAssignRideDriver(ride.id, e.target.value)}
                              className="rounded border border-stone-300 bg-white px-2.5 py-1 text-xs"
                            >
                              <option value="">Unassigned</option>
                              {state.drivers.map((drv) => (
                                <option key={drv.id} value={drv.id}>
                                  {drv.fullName} ({drv.vehicleClass})
                                </option>
                              ))}
                            </select>
                          </td>
                          <td className="px-6 py-3">
                            <select
                              aria-label={`Status for ${ride.id}`}
                              value={ride.status}
                              disabled={busyId === ride.id}
                              onChange={(e) => handleRideStatus(ride.id, e.target.value as RideStatus)}
                              className="rounded border border-stone-300 bg-white px-2.5 py-1 text-xs"
                            >
                              <option value="Requested">Requested</option>
                              <option value="Driver Assigned">Driver Assigned</option>
                              <option value="In Transit">In Transit</option>
                              <option value="Completed">Completed</option>
                              <option value="Cancelled">Cancelled</option>
                            </select>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
                <div className="lg:col-span-7 bg-white border border-stone-200 rounded-xl overflow-hidden">
                  <div className="px-6 py-4 border-b border-stone-200">
                    <h3 className="font-display text-base font-bold text-stone-900">
                      Registered Drivers &amp; Vehicles ({state.drivers.length})
                    </h3>
                  </div>
                  <div className="divide-y divide-stone-100">
                    {state.drivers.map((drv) => (
                      <div key={drv.id} className="p-4 sm:px-6 flex flex-wrap items-center justify-between gap-4 text-sm">
                        <div>
                          <p className="font-semibold text-stone-900">
                            {drv.fullName} · {drv.vehicleModel}
                          </p>
                          <p className="text-xs text-stone-500 font-mono">
                            {drv.plateNumber} · {drv.hubZone} · {drv.tripsCompleted} trips
                          </p>
                        </div>
                        <button
                          type="button"
                          disabled={busyId === drv.id}
                          onClick={() => handleToggleDriver(drv.id, !drv.available)}
                          className={`px-3 py-1.5 text-xs font-medium rounded-lg border cursor-pointer ${
                            drv.available
                              ? 'border-emerald-300 bg-emerald-50 text-emerald-800'
                              : 'border-stone-300 bg-stone-100 text-stone-600'
                          }`}
                        >
                          {drv.available ? 'Online / Available' : 'Off Duty'}
                        </button>
                      </div>
                    ))}
                  </div>
                </div>

                <form
                  onSubmit={handleAddDriver}
                  className="lg:col-span-5 bg-white border border-stone-200 rounded-xl p-6 space-y-3"
                >
                  <h3 className="font-display text-base font-bold text-stone-900">
                    Onboard New Fleet Driver
                  </h3>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label htmlFor="drv-name" className="block text-xs text-stone-600">
                        Full Name
                      </label>
                      <input
                        id="drv-name"
                        type="text"
                        value={drvName}
                        onChange={(e) => setDrvName(e.target.value)}
                        className="mt-1 w-full rounded-lg border border-stone-300 px-3 py-2 text-xs"
                      />
                    </div>
                    <div>
                      <label htmlFor="drv-phone" className="block text-xs text-stone-600">
                        Phone
                      </label>
                      <input
                        id="drv-phone"
                        type="tel"
                        value={drvPhone}
                        onChange={(e) => setDrvPhone(e.target.value)}
                        className="mt-1 w-full rounded-lg border border-stone-300 px-3 py-2 text-xs"
                      />
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label htmlFor="drv-vehicle" className="block text-xs text-stone-600">
                        Vehicle Model
                      </label>
                      <input
                        id="drv-vehicle"
                        type="text"
                        value={drvVehicle}
                        onChange={(e) => setDrvVehicle(e.target.value)}
                        placeholder="e.g. VW Polo Sedan"
                        className="mt-1 w-full rounded-lg border border-stone-300 px-3 py-2 text-xs"
                      />
                    </div>
                    <div>
                      <label htmlFor="drv-plate" className="block text-xs text-stone-600">
                        Plate Number
                      </label>
                      <input
                        id="drv-plate"
                        type="text"
                        value={drvPlate}
                        onChange={(e) => setDrvPlate(e.target.value)}
                        placeholder="MRL 102 NW"
                        className="mt-1 w-full rounded-lg border border-stone-300 px-3 py-2 text-xs font-mono"
                      />
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label htmlFor="drv-class" className="block text-xs text-stone-600">
                        Class
                      </label>
                      <select
                        id="drv-class"
                        value={drvClass}
                        onChange={(e) => setDrvClass(e.target.value as VehicleClass)}
                        className="mt-1 w-full rounded-lg border border-stone-300 px-2.5 py-2 text-xs bg-white"
                      >
                        <option value="Standard Sedan">Standard Sedan</option>
                        <option value="Executive SUV">Executive SUV</option>
                        <option value="Farm Cargo Utility">Farm Cargo Utility</option>
                      </select>
                    </div>
                    <div>
                      <label htmlFor="drv-hub" className="block text-xs text-stone-600">
                        Hub Zone
                      </label>
                      <input
                        id="drv-hub"
                        type="text"
                        value={drvHub}
                        onChange={(e) => setDrvHub(e.target.value)}
                        className="mt-1 w-full rounded-lg border border-stone-300 px-3 py-2 text-xs"
                      />
                    </div>
                  </div>
                  {driverFeedback && <p className="text-xs text-[#14532D] font-medium">{driverFeedback}</p>}
                  <button
                    type="submit"
                    className="inline-flex items-center gap-1.5 px-4 py-2 bg-[#14532D] text-white text-xs font-semibold rounded-lg hover:bg-[#114224] cursor-pointer"
                  >
                    <Plus className="h-3.5 w-3.5" />
                    Register Driver
                  </button>
                </form>
              </div>
            </div>
          )}

          {/* SECTION 4: MICROLENDING UNDERWRITING DESK */}
          {activeSection === 'microlending' && (
            <div className="bg-white border border-stone-200 rounded-xl overflow-hidden">
              <div className="px-6 py-4 border-b border-stone-200">
                <h2 className="font-display text-base font-bold text-stone-900">
                  Microloan Portfolio &amp; Underwriting Queue ({state.loans.length})
                </h2>
                <p className="text-xs text-stone-500">
                  Review income affordability, approve or disburse loans, and record installment payments.
                </p>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-left text-sm">
                  <thead className="bg-stone-50 text-xs text-stone-500 border-b border-stone-200">
                    <tr>
                      <th className="px-6 py-3 font-medium">Loan ID</th>
                      <th className="px-6 py-3 font-medium">Applicant</th>
                      <th className="px-6 py-3 font-medium text-right">Principal</th>
                      <th className="px-6 py-3 font-medium text-right">Installment</th>
                      <th className="px-6 py-3 font-medium text-right">Repaid / Total</th>
                      <th className="px-6 py-3 font-medium">Status</th>
                      <th className="px-6 py-3 font-medium text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-stone-100">
                    {state.loans.map((loan) => {
                      const dti =
                        loan.monthlyIncomeZar > 0
                          ? Math.round((loan.monthlyInstallmentZar / loan.monthlyIncomeZar) * 1000) / 10
                          : 0;
                      return (
                        <tr key={loan.id} className="hover:bg-stone-50">
                          <td className="px-6 py-3 font-mono text-xs text-stone-700">{loan.id}</td>
                          <td className="px-6 py-3">
                            <p className="font-semibold text-stone-900">{loan.applicantName}</p>
                            <p className="text-xs text-stone-500 tabular-nums">
                              {loan.purpose} · Income {formatZar(loan.monthlyIncomeZar)} (DTI {dti}%)
                            </p>
                          </td>
                          <td className="px-6 py-3 text-right font-mono tabular-nums text-stone-900">
                            {formatZar(loan.principalZar)}
                          </td>
                          <td className="px-6 py-3 text-right font-mono tabular-nums text-stone-700">
                            {formatZar(loan.monthlyInstallmentZar)} / mo
                          </td>
                          <td className="px-6 py-3 text-right font-mono tabular-nums text-xs">
                            {formatZar(loan.amountRepaidZar)} / {formatZar(loan.totalRepayableZar)}
                          </td>
                          <td className="px-6 py-3">
                            <select
                              aria-label={`Status for loan ${loan.id}`}
                              value={loan.status}
                              disabled={busyId === loan.id}
                              onChange={(e) => handleLoanStatus(loan.id, e.target.value as LoanStatus)}
                              className="rounded border border-stone-300 bg-white px-2.5 py-1 text-xs"
                            >
                              <option value="Pending Review">Pending Review</option>
                              <option value="Approved">Approved</option>
                              <option value="Disbursed">Disbursed</option>
                              <option value="Repaid">Repaid</option>
                              <option value="Declined">Declined</option>
                            </select>
                          </td>
                          <td className="px-6 py-3 text-right">
                            <div className="inline-flex items-center gap-2">
                              {loan.status === 'Pending Review' && (
                                <button
                                  type="button"
                                  disabled={busyId === loan.id}
                                  onClick={() => handleLoanStatus(loan.id, 'Approved')}
                                  className="px-2.5 py-1 bg-[#14532D] text-white text-xs font-semibold rounded hover:bg-[#114224] cursor-pointer"
                                >
                                  Approve
                                </button>
                              )}
                              {(loan.status === 'Approved' || loan.status === 'Disbursed') && (
                                <button
                                  type="button"
                                  disabled={busyId === loan.id}
                                  onClick={() => handleLoanRepayment(loan.id, loan.monthlyInstallmentZar)}
                                  className="px-2.5 py-1 border border-stone-300 bg-white text-stone-800 text-xs font-medium rounded hover:bg-stone-100 cursor-pointer"
                                >
                                  Record Installment
                                </button>
                              )}
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* SECTION 5: WEBSITE & GOOGLE PLAY CONSOLE VERIFICATION */}
          {activeSection === 'verification' && (
            <VerificationPanel
              verification={state.verification}
              onRefreshState={onRefreshState}
            />
          )}
        </div>
      </main>
    </div>
  );
}
