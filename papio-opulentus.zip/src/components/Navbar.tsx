import { Menu, X } from 'lucide-react';
import { useState } from 'react';

export type ActiveWorkspace = 'home' | 'portal' | 'dashboard';

interface NavbarProps {
  activeWorkspace: ActiveWorkspace;
  onNavigateWorkspace: (workspace: ActiveWorkspace, sectionOrTab?: string) => void;
}

export function Navbar({ activeWorkspace, onNavigateWorkspace }: NavbarProps) {
  const [mobileOpen, setMobileOpen] = useState(false);

  const handleLink = (workspace: ActiveWorkspace, sectionOrTab?: string) => {
    setMobileOpen(false);
    onNavigateWorkspace(workspace, sectionOrTab);
  };

  return (
    <header className="sticky top-0 z-40 border-b border-stone-200 bg-[#FAFAF9]/95 backdrop-blur-sm">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between gap-8 px-4 sm:px-6 lg:px-8">
        {/* Zone 1: Single-element Brand Wordmark */}
        <a
          href="#top"
          onClick={(e) => {
            e.preventDefault();
            handleLink('home', 'top');
          }}
          className="font-display text-lg font-bold tracking-tight text-stone-900 whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-[#14532D]"
        >
          Papio Opulentus
        </a>

        {/* Zone 2: Concise single-line navigation links */}
        <nav aria-label="Primary navigation" className="hidden md:flex items-center gap-6 text-sm font-medium text-stone-600">
          <button
            type="button"
            onClick={() => handleLink('home', 'top')}
            className={`whitespace-nowrap shrink-0 transition-colors duration-150 hover:text-stone-900 hover:underline underline-offset-4 cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-[#14532D] ${
              activeWorkspace === 'home' ? 'text-stone-900 underline' : ''
            }`}
          >
            Overview
          </button>
          <button
            type="button"
            onClick={() => handleLink('home', 'division-farm')}
            className="whitespace-nowrap shrink-0 transition-colors duration-150 hover:text-stone-900 hover:underline underline-offset-4 cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-[#14532D]"
          >
            Lesobeng Farm
          </button>
          <button
            type="button"
            onClick={() => handleLink('home', 'division-ehailing')}
            className="whitespace-nowrap shrink-0 transition-colors duration-150 hover:text-stone-900 hover:underline underline-offset-4 cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-[#14532D]"
          >
            E-Hailing
          </button>
          <button
            type="button"
            onClick={() => handleLink('home', 'division-microlending')}
            className="whitespace-nowrap shrink-0 transition-colors duration-150 hover:text-stone-900 hover:underline underline-offset-4 cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-[#14532D]"
          >
            Microlending
          </button>
          <button
            type="button"
            onClick={() => handleLink('portal', 'farm')}
            className={`whitespace-nowrap shrink-0 transition-colors duration-150 hover:text-stone-900 hover:underline underline-offset-4 cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-[#14532D] ${
              activeWorkspace === 'portal' ? 'text-[#14532D] font-semibold underline' : ''
            }`}
          >
            Client Portal
          </button>
        </nav>

        {/* Zone 3: Single Primary Action */}
        <div className="flex items-center gap-3 shrink-0">
          <button
            type="button"
            onClick={() => handleLink('dashboard', 'overview')}
            className={`px-4 py-2 text-xs sm:text-sm font-semibold rounded-lg transition-colors duration-150 whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#14532D] ${
              activeWorkspace === 'dashboard'
                ? 'bg-[#14532D] text-white'
                : 'bg-stone-900 text-white hover:bg-[#14532D]'
            }`}
          >
            Owner Dashboard
          </button>
          <button
            type="button"
            aria-label={mobileOpen ? 'Close navigation menu' : 'Open navigation menu'}
            aria-expanded={mobileOpen}
            onClick={() => setMobileOpen((prev) => !prev)}
            className="md:hidden p-2 rounded-lg text-stone-700 hover:bg-stone-200/60 cursor-pointer"
          >
            {mobileOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>
      </div>

      {mobileOpen && (
        <nav
          aria-label="Mobile navigation"
          className="md:hidden border-t border-stone-200 bg-[#FAFAF9] px-4 py-3 flex flex-col gap-1"
        >
          <button
            type="button"
            onClick={() => handleLink('home', 'top')}
            className="text-left px-3 py-2.5 text-sm font-medium text-stone-800 rounded-md hover:bg-stone-100 cursor-pointer"
          >
            Overview
          </button>
          <button
            type="button"
            onClick={() => handleLink('home', 'division-farm')}
            className="text-left px-3 py-2.5 text-sm font-medium text-stone-800 rounded-md hover:bg-stone-100 cursor-pointer"
          >
            Lesobeng Farm
          </button>
          <button
            type="button"
            onClick={() => handleLink('home', 'division-ehailing')}
            className="text-left px-3 py-2.5 text-sm font-medium text-stone-800 rounded-md hover:bg-stone-100 cursor-pointer"
          >
            E-Hailing
          </button>
          <button
            type="button"
            onClick={() => handleLink('home', 'division-microlending')}
            className="text-left px-3 py-2.5 text-sm font-medium text-stone-800 rounded-md hover:bg-stone-100 cursor-pointer"
          >
            Microlending
          </button>
          <button
            type="button"
            onClick={() => handleLink('portal', 'farm')}
            className="text-left px-3 py-2.5 text-sm font-semibold text-[#14532D] rounded-md hover:bg-stone-100 cursor-pointer"
          >
            Client Portal
          </button>
        </nav>
      )}
    </header>
  );
}
