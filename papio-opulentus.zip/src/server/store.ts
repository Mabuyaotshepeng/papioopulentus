import fs from 'node:fs';
import path from 'node:path';
import type { AppStatePayload } from '../types/domain.ts';

const DATA_DIR = path.resolve(process.cwd(), '.data');
const STORE_PATH = path.join(DATA_DIR, 'papio-store.json');

export function createSeedState(): AppStatePayload {
  const now = new Date().toISOString();

  return {
    company: {
      name: 'Papio Opulentus',
      owner: 'Mabuya Otshepeng Trevor',
      farmName: 'Lesobeng Farm',
      location: 'Moruleng Village, North West',
    },
    farmItems: [
      {
        id: 'farm-crop-1',
        name: 'White Milling Maize',
        category: 'crops',
        varietyOrBreed: 'PAN 5R-591R Non-GMO Hybrid',
        unit: '50kg Bag',
        quantityAvailable: 145,
        unitPriceZar: 420,
        status: 'Ready for Harvest',
        locationSection: 'Lesobeng North Block A',
        updatedAt: now,
      },
      {
        id: 'farm-crop-2',
        name: 'Fresh Garden Spinach & Morogo',
        category: 'crops',
        varietyOrBreed: 'Fordhook Giant / Heritage Cleome',
        unit: '10kg Crate',
        quantityAvailable: 68,
        unitPriceZar: 165,
        status: 'Healthy',
        locationSection: 'Drip Irrigation Plot 2',
        updatedAt: now,
      },
      {
        id: 'farm-crop-3',
        name: 'Red Sorghum Grain',
        category: 'crops',
        varietyOrBreed: 'Macia Drought-Tolerant',
        unit: '50kg Bag',
        quantityAvailable: 92,
        unitPriceZar: 510,
        status: 'Healthy',
        locationSection: 'Lesobeng East Dryland',
        updatedAt: now,
      },
      {
        id: 'farm-crop-4',
        name: 'Butternut Squash',
        category: 'crops',
        varietyOrBreed: 'Waltham Commercial',
        unit: '15kg Pocket',
        quantityAvailable: 84,
        unitPriceZar: 140,
        status: 'Ready for Harvest',
        locationSection: 'Drip Irrigation Plot 4',
        updatedAt: now,
      },
      {
        id: 'farm-live-1',
        name: 'Bonsmara Beef Weaners',
        category: 'livestock',
        varietyOrBreed: 'Registered Bonsmara (220–260kg)',
        unit: 'Head',
        quantityAvailable: 34,
        unitPriceZar: 11800,
        status: 'Healthy',
        locationSection: 'Lesobeng Grazing Camp 1',
        updatedAt: now,
      },
      {
        id: 'farm-live-2',
        name: 'Boer Goat Breeding Does',
        category: 'livestock',
        varietyOrBreed: 'Ennobled SA Boer Goat',
        unit: 'Head',
        quantityAvailable: 26,
        unitPriceZar: 3650,
        status: 'Healthy',
        locationSection: 'Small Stock Kraal B',
        updatedAt: now,
      },
      {
        id: 'farm-live-3',
        name: 'Free-Range Boschveld Layers',
        category: 'livestock',
        varietyOrBreed: 'Point-of-Lay Pullets (18 wks)',
        unit: 'Crate of 10',
        quantityAvailable: 19,
        unitPriceZar: 1350,
        status: 'Healthy',
        locationSection: 'Lesobeng Poultry House 2',
        updatedAt: now,
      },
    ],
    farmOrders: [
      {
        id: 'ORD-1041',
        clientName: 'Bakgatla Fresh Mart',
        clientPhone: '+27 82 419 8820',
        deliveryLocation: 'Moruleng Village',
        items: [
          { itemId: 'farm-crop-1', itemName: 'White Milling Maize', quantity: 10, unitPriceZar: 420 },
          { itemId: 'farm-crop-2', itemName: 'Fresh Garden Spinach & Morogo', quantity: 6, unitPriceZar: 165 },
        ],
        subtotalZar: 5190,
        deliveryFeeZar: 0,
        totalZar: 5190,
        status: 'Confirmed',
        createdAt: now,
      },
      {
        id: 'ORD-1042',
        clientName: 'Mogwase Butchery & Grill',
        clientPhone: '+27 71 904 3312',
        deliveryLocation: 'Mogwase Unit 4',
        items: [
          { itemId: 'farm-live-2', itemName: 'Boer Goat Breeding Does', quantity: 2, unitPriceZar: 3650 },
        ],
        subtotalZar: 7300,
        deliveryFeeZar: 0,
        totalZar: 7300,
        status: 'Pending',
        createdAt: now,
      },
    ],
    drivers: [
      {
        id: 'DRV-01',
        fullName: 'Thabo Molefe',
        phone: '+27 83 512 4091',
        vehicleModel: 'Toyota Corolla Quest 1.8',
        vehicleClass: 'Standard Sedan',
        plateNumber: 'KPZ 482 NW',
        hubZone: 'Moruleng Central Hub',
        available: true,
        tripsCompleted: 318,
      },
      {
        id: 'DRV-02',
        fullName: 'Kealeboga Ndlovu',
        phone: '+27 72 884 1903',
        vehicleModel: 'Toyota Fortuner 2.8 GD-6',
        vehicleClass: 'Executive SUV',
        plateNumber: 'LBM 910 NW',
        hubZone: 'Sun City & Pilanesberg Gate',
        available: true,
        tripsCompleted: 204,
      },
      {
        id: 'DRV-03',
        fullName: 'Kagiso Mokoena',
        phone: '+27 79 341 7725',
        vehicleModel: 'Isuzu D-Max Single Cab',
        vehicleClass: 'Farm Cargo Utility',
        plateNumber: 'JVR 307 NW',
        hubZone: 'Lesobeng Farm & Mogwase',
        available: true,
        tripsCompleted: 147,
      },
    ],
    rides: [
      {
        id: 'RIDE-508',
        passengerName: 'Lerato Phiri',
        passengerPhone: '+27 84 221 9044',
        pickupLocation: 'Moruleng Village Mall',
        dropoffLocation: 'Sun City Main Gate',
        distanceKm: 18,
        vehicleClass: 'Standard Sedan',
        estimatedFareZar: 242,
        estimatedMinutes: 23,
        assignedDriverId: 'DRV-01',
        assignedDriverName: 'Thabo Molefe',
        status: 'In Transit',
        createdAt: now,
      },
      {
        id: 'RIDE-509',
        passengerName: 'Tshepo Ramokgopa',
        passengerPhone: '+27 76 618 4410',
        pickupLocation: 'Lesobeng Farm Gate',
        dropoffLocation: 'Rustenburg CBD',
        distanceKm: 58,
        vehicleClass: 'Executive SUV',
        estimatedFareZar: 993,
        estimatedMinutes: 60,
        assignedDriverId: null,
        assignedDriverName: null,
        status: 'Requested',
        createdAt: now,
      },
    ],
    loans: [
      {
        id: 'LN-801',
        applicantName: 'Nomsa Kgosi',
        applicantPhone: '+27 82 770 1429',
        nationalIdLast4: '4821',
        monthlyIncomeZar: 14500,
        principalZar: 6000,
        termMonths: 6,
        monthlyRatePct: 3.5,
        monthlyInstallmentZar: 1279.17,
        totalInterestZar: 1260,
        totalRepayableZar: 7675,
        amountRepaidZar: 2558.34,
        purpose: 'Working Capital',
        status: 'Disbursed',
        createdAt: now,
      },
      {
        id: 'LN-802',
        applicantName: 'Ofentse Sebogodi',
        applicantPhone: '+27 73 410 6651',
        nationalIdLast4: '9103',
        monthlyIncomeZar: 11200,
        principalZar: 4000,
        termMonths: 4,
        monthlyRatePct: 3.5,
        monthlyInstallmentZar: 1218.75,
        totalInterestZar: 560,
        totalRepayableZar: 4875,
        amountRepaidZar: 0,
        purpose: 'Agricultural Inputs',
        status: 'Pending Review',
        createdAt: now,
      },
    ],
    verification: {
      primaryDomain: 'papioopulentus.co.za',
      dnsTxtToken: 'google-site-verification=papio_opulentus_lesobeng_2026_verified',
      assetLinks: [
        {
          id: 'app-client',
          label: 'Papio Opulentus Client & E-Hailing Android App',
          packageName: 'com.papioopulentus.client',
          sha256Fingerprints: [
            '9A:4B:12:8E:7C:D0:19:55:A3:F4:22:6B:81:0D:E7:3C:49:10:FA:88:23:6E:5B:90:12:34:56:78:9A:BC:DE:F0',
          ],
          relations: ['delegate_permission/common.handle_all_urls'],
          enabled: true,
        },
      ],
      htmlFiles: [
        {
          id: 'html-google-1',
          provider: 'Google Search & Play Console',
          filename: 'google7c4e91a2b80f3d15.html',
          content: 'google-site-verification: google7c4e91a2b80f3d15.html',
          enabled: true,
          updatedAt: now,
        },
      ],
      metaTags: [
        {
          id: 'meta-google-1',
          provider: 'Google Site Verification',
          metaName: 'google-site-verification',
          metaContent: 'papioOpulentusMorulengVerify2026',
          enabled: true,
        },
      ],
      appleAssociation: {
        enabled: true,
        appId: '8X92P4Q1LM.com.papioopulentus.client',
        paths: ['/portal/*', '/rides/*', '/loans/*'],
      },
      lastUpdated: now,
    },
  };
}

export function loadState(): AppStatePayload {
  try {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
    if (!fs.existsSync(STORE_PATH)) {
      const seed = createSeedState();
      fs.writeFileSync(STORE_PATH, JSON.stringify(seed, null, 2), 'utf-8');
      return seed;
    }
    const raw = fs.readFileSync(STORE_PATH, 'utf-8');
    const parsed = JSON.parse(raw) as AppStatePayload;
    return parsed;
  } catch {
    const seed = createSeedState();
    saveState(seed);
    return seed;
  }
}

export function saveState(state: AppStatePayload): void {
  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }
  const tmpPath = `${STORE_PATH}.tmp`;
  fs.writeFileSync(tmpPath, JSON.stringify(state, null, 2), 'utf-8');
  fs.renameSync(tmpPath, STORE_PATH);
}
