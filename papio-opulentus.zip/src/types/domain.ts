export type FarmCategory = 'crops' | 'livestock';

export type FarmHealthStatus = 'Healthy' | 'Ready for Harvest' | 'Quarantine Review' | 'Low Stock';

export interface FarmItem {
  id: string;
  name: string;
  category: FarmCategory;
  varietyOrBreed: string;
  unit: string;
  quantityAvailable: number;
  unitPriceZar: number;
  status: FarmHealthStatus;
  locationSection: string;
  updatedAt: string;
}

export type FarmOrderStatus = 'Pending' | 'Confirmed' | 'Dispatched' | 'Fulfilled' | 'Cancelled';

export interface FarmOrderLine {
  itemId: string;
  itemName: string;
  quantity: number;
  unitPriceZar: number;
}

export interface FarmOrder {
  id: string;
  clientName: string;
  clientPhone: string;
  deliveryLocation: string;
  items: FarmOrderLine[];
  subtotalZar: number;
  deliveryFeeZar: number;
  totalZar: number;
  status: FarmOrderStatus;
  createdAt: string;
}

export type VehicleClass = 'Standard Sedan' | 'Executive SUV' | 'Farm Cargo Utility';

export type RideStatus = 'Requested' | 'Driver Assigned' | 'In Transit' | 'Completed' | 'Cancelled';

export interface DriverRecord {
  id: string;
  fullName: string;
  phone: string;
  vehicleModel: string;
  vehicleClass: VehicleClass;
  plateNumber: string;
  hubZone: string;
  available: boolean;
  tripsCompleted: number;
}

export interface RideBooking {
  id: string;
  passengerName: string;
  passengerPhone: string;
  pickupLocation: string;
  dropoffLocation: string;
  distanceKm: number;
  vehicleClass: VehicleClass;
  estimatedFareZar: number;
  estimatedMinutes: number;
  assignedDriverId: string | null;
  assignedDriverName: string | null;
  status: RideStatus;
  createdAt: string;
}

export type LoanPurpose =
  | 'Working Capital'
  | 'Agricultural Inputs'
  | 'Transport & Logistics'
  | 'Personal Emergency';

export type LoanStatus = 'Pending Review' | 'Approved' | 'Disbursed' | 'Repaid' | 'Declined';

export interface LoanApplication {
  id: string;
  applicantName: string;
  applicantPhone: string;
  nationalIdLast4: string;
  monthlyIncomeZar: number;
  principalZar: number;
  termMonths: number;
  monthlyRatePct: number;
  monthlyInstallmentZar: number;
  totalInterestZar: number;
  totalRepayableZar: number;
  amountRepaidZar: number;
  purpose: LoanPurpose;
  status: LoanStatus;
  createdAt: string;
}

export interface AssetLinkApp {
  id: string;
  label: string;
  packageName: string;
  sha256Fingerprints: string[];
  relations: string[];
  enabled: boolean;
}

export interface HtmlVerificationFile {
  id: string;
  provider: string;
  filename: string;
  content: string;
  enabled: boolean;
  updatedAt: string;
}

export interface MetaVerificationTag {
  id: string;
  provider: string;
  metaName: string;
  metaContent: string;
  enabled: boolean;
}

export interface AppleAssociationConfig {
  enabled: boolean;
  appId: string;
  paths: string[];
}

export interface VerificationConfig {
  primaryDomain: string;
  dnsTxtToken: string;
  assetLinks: AssetLinkApp[];
  htmlFiles: HtmlVerificationFile[];
  metaTags: MetaVerificationTag[];
  appleAssociation: AppleAssociationConfig;
  lastUpdated: string;
}

export interface VerificationProbeCheck {
  id: string;
  label: string;
  endpoint: string;
  ok: boolean;
  statusCode: number;
  contentType: string;
  preview: string;
}

export interface AppStatePayload {
  company: {
    name: string;
    owner: string;
    farmName: string;
    location: string;
  };
  farmItems: FarmItem[];
  farmOrders: FarmOrder[];
  drivers: DriverRecord[];
  rides: RideBooking[];
  loans: LoanApplication[];
  verification: VerificationConfig;
}
