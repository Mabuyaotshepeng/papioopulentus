import express from 'express';
import fs from 'node:fs';
import path from 'node:path';
import { createServer as createViteServer } from 'vite';
import {
  buildAssetLinksPayload,
  calculateFarmOrderTotal,
  calculateMicroloan,
  calculateRideFare,
  escapeHtmlAttr,
  isValidAndroidPackageName,
  isValidSha256Fingerprint,
  isValidVerificationHtmlFilename,
} from './src/utils/businessLogic.ts';
import { loadState, saveState } from './src/server/store.ts';
import type {
  FarmOrderLine,
  LoanPurpose,
  VehicleClass,
  VerificationConfig,
  VerificationProbeCheck,
} from './src/types/domain.ts';

const PORT = Number(process.env.PORT || 3000);
const IS_PROD = process.env.NODE_ENV === 'production';

function renderVerificationMetaHtml(config: VerificationConfig): string {
  return config.metaTags
    .filter((tag) => tag.enabled && tag.metaName.trim() && tag.metaContent.trim())
    .map(
      (tag) =>
        `<meta name="${escapeHtmlAttr(tag.metaName.trim())}" content="${escapeHtmlAttr(tag.metaContent.trim())}" />`
    )
    .join('\n    ');
}

function injectVerificationMeta(html: string, config: VerificationConfig): string {
  const tagsHtml = renderVerificationMetaHtml(config);
  if (html.includes('<!-- VERIFICATION_META_TAGS -->')) {
    return html.replace('<!-- VERIFICATION_META_TAGS -->', tagsHtml);
  }
  return html.replace('</head>', `    ${tagsHtml}\n  </head>`);
}

async function startServer(): Promise<void> {
  const app = express();
  app.use(express.json({ limit: '1mb' }));

  // 1. Google Play Console Digital Asset Links endpoint
  app.get('/.well-known/assetlinks.json', (_req, res) => {
    const state = loadState();
    const payload = buildAssetLinksPayload(state.verification.assetLinks);
    res.setHeader('Content-Type', 'application/json; charset=utf-8');
    res.setHeader('Cache-Control', 'no-store');
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.status(200).send(JSON.stringify(payload, null, 2));
  });

  // 2. Apple App Site Association endpoint
  app.get('/.well-known/apple-app-site-association', (_req, res) => {
    const state = loadState();
    const cfg = state.verification.appleAssociation;
    if (!cfg.enabled) {
      res.status(404).json({ error: 'Apple App Site Association is disabled' });
      return;
    }
    res.setHeader('Content-Type', 'application/json; charset=utf-8');
    res.setHeader('Cache-Control', 'no-store');
    res.status(200).send(
      JSON.stringify(
        {
          applinks: {
            apps: [],
            details: [
              {
                appID: cfg.appId,
                paths: cfg.paths,
              },
            ],
          },
        },
        null,
        2
      )
    );
  });

  // 3. Dynamic Google / External HTML Verification File routes
  app.get('/:filename', (req, res, next) => {
    const filename = req.params.filename;
    if (!filename.endsWith('.html')) {
      next();
      return;
    }
    const state = loadState();
    const matched = state.verification.htmlFiles.find(
      (file) => file.enabled && file.filename.replace(/^\/+/, '') === filename
    );
    if (!matched) {
      next();
      return;
    }
    res.setHeader('Content-Type', 'text/html; charset=utf-8');
    res.setHeader('Cache-Control', 'no-store');
    res.status(200).send(matched.content);
  });

  // 4. REST API Routes
  app.get('/api/state', (_req, res) => {
    res.json(loadState());
  });

  // Lesobeng Farm Items
  app.post('/api/farm/items', (req, res) => {
    const state = loadState();
    const { name, category, varietyOrBreed, unit, quantityAvailable, unitPriceZar, status, locationSection } =
      req.body ?? {};

    if (!name || typeof name !== 'string' || !name.trim()) {
      res.status(400).json({ error: 'Item name is required.' });
      return;
    }
    if (category !== 'crops' && category !== 'livestock') {
      res.status(400).json({ error: 'Category must be crops or livestock.' });
      return;
    }
    const qty = Number(quantityAvailable);
    const price = Number(unitPriceZar);
    if (!Number.isFinite(qty) || qty < 0 || !Number.isFinite(price) || price <= 0) {
      res.status(400).json({ error: 'Valid non-negative quantity and positive price are required.' });
      return;
    }

    const newItem = {
      id: `farm-${category}-${Date.now()}`,
      name: name.trim(),
      category,
      varietyOrBreed: String(varietyOrBreed || 'Lesobeng Standard').trim(),
      unit: String(unit || 'Unit').trim(),
      quantityAvailable: Math.round(qty),
      unitPriceZar: Math.round(price * 100) / 100,
      status: status || 'Healthy',
      locationSection: String(locationSection || 'Lesobeng Main Estate').trim(),
      updatedAt: new Date().toISOString(),
    };

    state.farmItems.unshift(newItem);
    saveState(state);
    res.status(201).json(newItem);
  });

  app.patch('/api/farm/items/:id', (req, res) => {
    const state = loadState();
    const item = state.farmItems.find((entry) => entry.id === req.params.id);
    if (!item) {
      res.status(404).json({ error: 'Farm item not found.' });
      return;
    }
    const { quantityAvailable, unitPriceZar, status } = req.body ?? {};
    if (quantityAvailable !== undefined) {
      const q = Number(quantityAvailable);
      if (!Number.isFinite(q) || q < 0) {
        res.status(400).json({ error: 'Invalid quantity.' });
        return;
      }
      item.quantityAvailable = Math.round(q);
    }
    if (unitPriceZar !== undefined) {
      const p = Number(unitPriceZar);
      if (!Number.isFinite(p) || p <= 0) {
        res.status(400).json({ error: 'Invalid unit price.' });
        return;
      }
      item.unitPriceZar = Math.round(p * 100) / 100;
    }
    if (status) {
      item.status = status;
    }
    item.updatedAt = new Date().toISOString();
    saveState(state);
    res.json(item);
  });

  app.delete('/api/farm/items/:id', (req, res) => {
    const state = loadState();
    const prevLen = state.farmItems.length;
    state.farmItems = state.farmItems.filter((entry) => entry.id !== req.params.id);
    if (state.farmItems.length === prevLen) {
      res.status(404).json({ error: 'Farm item not found.' });
      return;
    }
    saveState(state);
    res.json({ deleted: true });
  });

  // Lesobeng Farm Client Orders
  app.post('/api/farm/orders', (req, res) => {
    const state = loadState();
    const { clientName, clientPhone, deliveryLocation, items } = req.body ?? {};

    if (!clientName || !String(clientName).trim() || !clientPhone || !String(clientPhone).trim()) {
      res.status(400).json({ error: 'Client name and phone number are required.' });
      return;
    }
    if (!deliveryLocation || !String(deliveryLocation).trim()) {
      res.status(400).json({ error: 'Delivery or pickup location is required.' });
      return;
    }
    if (!Array.isArray(items) || items.length === 0) {
      res.status(400).json({ error: 'Select at least one crop or livestock item.' });
      return;
    }

    const verifiedLines: FarmOrderLine[] = [];
    for (const line of items) {
      const catalogItem = state.farmItems.find((entry) => entry.id === line.itemId);
      const qty = Math.round(Number(line.quantity));
      if (!catalogItem || !Number.isFinite(qty) || qty <= 0) {
        res.status(400).json({ error: 'Invalid item or quantity in order.' });
        return;
      }
      if (qty > catalogItem.quantityAvailable) {
        res.status(400).json({
          error: `Insufficient stock for ${catalogItem.name} (${catalogItem.quantityAvailable} available).`,
        });
        return;
      }
      verifiedLines.push({
        itemId: catalogItem.id,
        itemName: catalogItem.name,
        quantity: qty,
        unitPriceZar: catalogItem.unitPriceZar,
      });
    }

    for (const line of verifiedLines) {
      const catalogItem = state.farmItems.find((entry) => entry.id === line.itemId);
      if (catalogItem) {
        catalogItem.quantityAvailable = Math.max(0, catalogItem.quantityAvailable - line.quantity);
        if (catalogItem.quantityAvailable <= 5 && catalogItem.status === 'Healthy') {
          catalogItem.status = 'Low Stock';
        }
        catalogItem.updatedAt = new Date().toISOString();
      }
    }

    const totals = calculateFarmOrderTotal(verifiedLines, String(deliveryLocation));
    const order = {
      id: `ORD-${Math.floor(1050 + Math.random() * 8900)}`,
      clientName: String(clientName).trim(),
      clientPhone: String(clientPhone).trim(),
      deliveryLocation: String(deliveryLocation).trim(),
      items: verifiedLines,
      ...totals,
      status: 'Pending' as const,
      createdAt: new Date().toISOString(),
    };

    state.farmOrders.unshift(order);
    saveState(state);
    res.status(201).json(order);
  });

  app.patch('/api/farm/orders/:id', (req, res) => {
    const state = loadState();
    const order = state.farmOrders.find((entry) => entry.id === req.params.id);
    if (!order) {
      res.status(404).json({ error: 'Order not found.' });
      return;
    }
    if (req.body?.status) {
      order.status = req.body.status;
    }
    saveState(state);
    res.json(order);
  });

  // E-Hailing Drivers & Rides
  app.post('/api/ehailing/drivers', (req, res) => {
    const state = loadState();
    const { fullName, phone, vehicleModel, vehicleClass, plateNumber, hubZone } = req.body ?? {};
    if (!fullName || !phone || !vehicleModel || !plateNumber) {
      res.status(400).json({ error: 'Driver name, phone, vehicle model, and plate number are required.' });
      return;
    }
    const newDriver = {
      id: `DRV-${String(state.drivers.length + 1).padStart(2, '0')}-${Date.now().toString().slice(-3)}`,
      fullName: String(fullName).trim(),
      phone: String(phone).trim(),
      vehicleModel: String(vehicleModel).trim(),
      vehicleClass: (vehicleClass || 'Standard Sedan') as VehicleClass,
      plateNumber: String(plateNumber).trim().toUpperCase(),
      hubZone: String(hubZone || 'Moruleng Central Hub').trim(),
      available: true,
      tripsCompleted: 0,
    };
    state.drivers.push(newDriver);
    saveState(state);
    res.status(201).json(newDriver);
  });

  app.patch('/api/ehailing/drivers/:id', (req, res) => {
    const state = loadState();
    const driver = state.drivers.find((entry) => entry.id === req.params.id);
    if (!driver) {
      res.status(404).json({ error: 'Driver not found.' });
      return;
    }
    if (typeof req.body?.available === 'boolean') {
      driver.available = req.body.available;
    }
    saveState(state);
    res.json(driver);
  });

  app.post('/api/ehailing/rides', (req, res) => {
    const state = loadState();
    const { passengerName, passengerPhone, pickupLocation, dropoffLocation, distanceKm, vehicleClass } =
      req.body ?? {};

    if (!passengerName || !String(passengerName).trim() || !passengerPhone || !String(passengerPhone).trim()) {
      res.status(400).json({ error: 'Passenger name and phone are required.' });
      return;
    }
    if (!pickupLocation || !dropoffLocation) {
      res.status(400).json({ error: 'Pickup and drop-off locations are required.' });
      return;
    }
    const dist = Number(distanceKm);
    if (!Number.isFinite(dist) || dist <= 0) {
      res.status(400).json({ error: 'Distance in km must be greater than zero.' });
      return;
    }
    const validClass: VehicleClass =
      vehicleClass === 'Executive SUV' || vehicleClass === 'Farm Cargo Utility'
        ? vehicleClass
        : 'Standard Sedan';

    const fare = calculateRideFare(dist, validClass);
    const ride = {
      id: `RIDE-${Math.floor(510 + Math.random() * 4400)}`,
      passengerName: String(passengerName).trim(),
      passengerPhone: String(passengerPhone).trim(),
      pickupLocation: String(pickupLocation).trim(),
      dropoffLocation: String(dropoffLocation).trim(),
      distanceKm: fare.distanceKm,
      vehicleClass: validClass,
      estimatedFareZar: fare.estimatedFareZar,
      estimatedMinutes: fare.estimatedMinutes,
      assignedDriverId: null,
      assignedDriverName: null,
      status: 'Requested' as const,
      createdAt: new Date().toISOString(),
    };

    state.rides.unshift(ride);
    saveState(state);
    res.status(201).json(ride);
  });

  app.patch('/api/ehailing/rides/:id', (req, res) => {
    const state = loadState();
    const ride = state.rides.find((entry) => entry.id === req.params.id);
    if (!ride) {
      res.status(404).json({ error: 'Ride booking not found.' });
      return;
    }

    const { status, assignedDriverId } = req.body ?? {};
    if (assignedDriverId !== undefined) {
      if (assignedDriverId === null || assignedDriverId === '') {
        ride.assignedDriverId = null;
        ride.assignedDriverName = null;
      } else {
        const driver = state.drivers.find((d) => d.id === assignedDriverId);
        if (!driver) {
          res.status(404).json({ error: 'Selected driver not found.' });
          return;
        }
        ride.assignedDriverId = driver.id;
        ride.assignedDriverName = driver.fullName;
        if (ride.status === 'Requested' && !status) {
          ride.status = 'Driver Assigned';
        }
      }
    }
    if (status) {
      const wasCompleted = ride.status === 'Completed';
      ride.status = status;
      if (!wasCompleted && status === 'Completed' && ride.assignedDriverId) {
        const driver = state.drivers.find((d) => d.id === ride.assignedDriverId);
        if (driver) {
          driver.tripsCompleted += 1;
        }
      }
    }

    saveState(state);
    res.json(ride);
  });

  // Microlending Desk
  app.post('/api/microlending/loans', (req, res) => {
    const state = loadState();
    const {
      applicantName,
      applicantPhone,
      nationalIdLast4,
      monthlyIncomeZar,
      principalZar,
      termMonths,
      purpose,
    } = req.body ?? {};

    if (!applicantName || !String(applicantName).trim() || !applicantPhone || !String(applicantPhone).trim()) {
      res.status(400).json({ error: 'Applicant name and phone are required.' });
      return;
    }
    const idLast4 = String(nationalIdLast4 || '').trim();
    if (!/^\d{4}$/.test(idLast4)) {
      res.status(400).json({ error: 'Enter the last 4 digits of your South African ID number.' });
      return;
    }
    const income = Number(monthlyIncomeZar);
    const principal = Number(principalZar);
    const term = Number(termMonths);
    if (!Number.isFinite(income) || income < 1500) {
      res.status(400).json({ error: 'Verified monthly income must be at least R 1,500.' });
      return;
    }
    if (!Number.isFinite(principal) || principal < 500 || principal > 50000) {
      res.status(400).json({ error: 'Loan amount must be between R 500 and R 50,000.' });
      return;
    }
    if (!Number.isFinite(term) || term < 1 || term > 24) {
      res.status(400).json({ error: 'Repayment term must be between 1 and 24 months.' });
      return;
    }

    const calc = calculateMicroloan(principal, term, 3.5, income);
    const loan = {
      id: `LN-${Math.floor(810 + Math.random() * 9100)}`,
      applicantName: String(applicantName).trim(),
      applicantPhone: String(applicantPhone).trim(),
      nationalIdLast4: idLast4,
      monthlyIncomeZar: Math.round(income),
      principalZar: calc.principalZar,
      termMonths: calc.termMonths,
      monthlyRatePct: calc.monthlyRatePct,
      monthlyInstallmentZar: calc.monthlyInstallmentZar,
      totalInterestZar: calc.totalInterestZar,
      totalRepayableZar: calc.totalRepayableZar,
      amountRepaidZar: 0,
      purpose: (purpose || 'Working Capital') as LoanPurpose,
      status: 'Pending Review' as const,
      createdAt: new Date().toISOString(),
    };

    state.loans.unshift(loan);
    saveState(state);
    res.status(201).json(loan);
  });

  app.patch('/api/microlending/loans/:id', (req, res) => {
    const state = loadState();
    const loan = state.loans.find((entry) => entry.id === req.params.id);
    if (!loan) {
      res.status(404).json({ error: 'Loan record not found.' });
      return;
    }

    const { status, repaymentPaymentZar } = req.body ?? {};
    if (repaymentPaymentZar !== undefined) {
      const payment = Number(repaymentPaymentZar);
      if (!Number.isFinite(payment) || payment <= 0) {
        res.status(400).json({ error: 'Repayment amount must be positive.' });
        return;
      }
      loan.amountRepaidZar = Math.min(
        loan.totalRepayableZar,
        Math.round((loan.amountRepaidZar + payment) * 100) / 100
      );
      if (loan.amountRepaidZar >= loan.totalRepayableZar) {
        loan.status = 'Repaid';
      }
    }
    if (status) {
      loan.status = status;
    }

    saveState(state);
    res.json(loan);
  });

  // External Website & Google Play Console Verification Config
  app.put('/api/verification', (req, res) => {
    const state = loadState();
    const incoming = req.body as Partial<VerificationConfig> | undefined;
    if (!incoming) {
      res.status(400).json({ error: 'Verification configuration payload is required.' });
      return;
    }

    if (incoming.assetLinks) {
      for (const appEntry of incoming.assetLinks) {
        if (!isValidAndroidPackageName(appEntry.packageName)) {
          res.status(400).json({
            error: `Invalid Android package name: "${appEntry.packageName}". Expected format like com.papioopulentus.client`,
          });
          return;
        }
        for (const fp of appEntry.sha256Fingerprints) {
          if (!isValidSha256Fingerprint(fp)) {
            res.status(400).json({
              error: `Invalid SHA-256 fingerprint for ${appEntry.packageName}. Must be 32 colon-separated hex pairs.`,
            });
            return;
          }
        }
      }
    }

    if (incoming.htmlFiles) {
      for (const file of incoming.htmlFiles) {
        if (!isValidVerificationHtmlFilename(file.filename)) {
          res.status(400).json({
            error: `Invalid verification filename "${file.filename}". Must be a safe .html filename (e.g. google1234abcd.html).`,
          });
          return;
        }
      }
    }

    state.verification = {
      ...state.verification,
      ...incoming,
      lastUpdated: new Date().toISOString(),
    };
    saveState(state);
    res.json(state.verification);
  });

  // Live Endpoint Probe for Google Play Console / Search Console verification
  app.post('/api/verification/probe', async (_req, res) => {
    const state = loadState();
    const baseUrl = `http://127.0.0.1:${PORT}`;
    const checks: VerificationProbeCheck[] = [];

    // Check 1: /.well-known/assetlinks.json
    try {
      const r = await fetch(`${baseUrl}/.well-known/assetlinks.json`);
      const text = await r.text();
      checks.push({
        id: 'probe-assetlinks',
        label: 'Google Play Console Digital Asset Links',
        endpoint: '/.well-known/assetlinks.json',
        ok: r.ok && text.includes('android_app'),
        statusCode: r.status,
        contentType: r.headers.get('content-type') || 'unknown',
        preview: text.slice(0, 260),
      });
    } catch (err) {
      checks.push({
        id: 'probe-assetlinks',
        label: 'Google Play Console Digital Asset Links',
        endpoint: '/.well-known/assetlinks.json',
        ok: false,
        statusCode: 0,
        contentType: 'error',
        preview: err instanceof Error ? err.message : 'Request failed',
      });
    }

    // Check 2: Enabled HTML verification files
    for (const file of state.verification.htmlFiles.filter((f) => f.enabled)) {
      const cleanName = file.filename.replace(/^\/+/, '');
      try {
        const r = await fetch(`${baseUrl}/${cleanName}`);
        const text = await r.text();
        checks.push({
          id: `probe-html-${file.id}`,
          label: `${file.provider} HTML File`,
          endpoint: `/${cleanName}`,
          ok: r.ok && text.trim() === file.content.trim(),
          statusCode: r.status,
          contentType: r.headers.get('content-type') || 'unknown',
          preview: text.slice(0, 180),
        });
      } catch (err) {
        checks.push({
          id: `probe-html-${file.id}`,
          label: `${file.provider} HTML File`,
          endpoint: `/${cleanName}`,
          ok: false,
          statusCode: 0,
          contentType: 'error',
          preview: err instanceof Error ? err.message : 'Request failed',
        });
      }
    }

    // Check 3: Root HTML <meta> verification tags
    try {
      const r = await fetch(`${baseUrl}/`);
      const html = await r.text();
      const enabledMetas = state.verification.metaTags.filter((m) => m.enabled);
      const allPresent = enabledMetas.every(
        (m) => html.includes(escapeHtmlAttr(m.metaName.trim())) && html.includes(escapeHtmlAttr(m.metaContent.trim()))
      );
      checks.push({
        id: 'probe-meta',
        label: 'Root HTML <meta> Verification Tags',
        endpoint: '/',
        ok: r.ok && allPresent,
        statusCode: r.status,
        contentType: r.headers.get('content-type') || 'unknown',
        preview:
          enabledMetas.length > 0
            ? enabledMetas.map((m) => `<meta name="${m.metaName}" content="${m.metaContent}" />`).join(' | ')
            : 'No enabled meta verification tags',
      });
    } catch (err) {
      checks.push({
        id: 'probe-meta',
        label: 'Root HTML <meta> Verification Tags',
        endpoint: '/',
        ok: false,
        statusCode: 0,
        contentType: 'error',
        preview: err instanceof Error ? err.message : 'Request failed',
      });
    }

    // Check 4: Apple App Site Association
    if (state.verification.appleAssociation.enabled) {
      try {
        const r = await fetch(`${baseUrl}/.well-known/apple-app-site-association`);
        const text = await r.text();
        checks.push({
          id: 'probe-apple',
          label: 'Apple Universal Links Association',
          endpoint: '/.well-known/apple-app-site-association',
          ok: r.ok && text.includes('applinks'),
          statusCode: r.status,
          contentType: r.headers.get('content-type') || 'unknown',
          preview: text.slice(0, 200),
        });
      } catch (err) {
        checks.push({
          id: 'probe-apple',
          label: 'Apple Universal Links Association',
          endpoint: '/.well-known/apple-app-site-association',
          ok: false,
          statusCode: 0,
          contentType: 'error',
          preview: err instanceof Error ? err.message : 'Request failed',
        });
      }
    }

    res.json({ checkedAt: new Date().toISOString(), checks });
  });

  // 5. Vite Dev Middleware / Production Static Serving with Dynamic Meta Injection
  if (!IS_PROD) {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'custom',
    });
    app.use(vite.middlewares);

    app.use('*', async (req, res, next) => {
      if (req.originalUrl.startsWith('/api') || req.originalUrl.startsWith('/.well-known')) {
        next();
        return;
      }
      try {
        const templatePath = path.resolve(process.cwd(), 'index.html');
        let template = fs.readFileSync(templatePath, 'utf-8');
        template = await vite.transformIndexHtml(req.originalUrl, template);
        const state = loadState();
        const html = injectVerificationMeta(template, state.verification);
        res.status(200).set({ 'Content-Type': 'text/html' }).end(html);
      } catch (err) {
        vite.ssrFixStacktrace(err as Error);
        next(err);
      }
    });
  } else {
    const distDir = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distDir, { index: false }));
    app.get('*', (_req, res) => {
      const indexFile = path.join(distDir, 'index.html');
      const template = fs.readFileSync(indexFile, 'utf-8');
      const state = loadState();
      const html = injectVerificationMeta(template, state.verification);
      res.status(200).set({ 'Content-Type': 'text/html' }).end(html);
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Papio Opulentus server listening on http://localhost:${PORT}`);
  });
}

startServer();
